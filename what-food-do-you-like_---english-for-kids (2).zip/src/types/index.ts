export type FoodId = 'rice' | 'omelet' | 'tofu' | 'noodles' | 'meatball';

export interface FoodItem {
  id: FoodId;
  name: string;
  indonesianName: string;
  image: string;
  color: string;
  borderColor: string;
  bgColor: string;
  textColor: string;
  description: string;
  exampleSentence: string;
  clues: string[];
}

export type NavTab = 
  | 'pembuka' 
  | 'tujuan' 
  | 'bahan-ajar' 
  | 'latihan' 
  | 'games' 
  | 'skor';

export interface LearningProgress {
  vocabulary: number; // 0 - 100
  grammar: number;    // 0 - 100
  practice: number;   // 0 - 100
  games: number;      // 0 - 100
  competition: number;// 0 - 100
}

export interface Player {
  id: number;
  name: string;
  score: number;
  correctAnswers: number;
  fastAnswers: number;
  avatarColor: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  iconType: 'star' | 'trophy' | 'target' | 'puzzle' | 'zap';
  unlocked: boolean;
  unlockedAt?: string;
}
