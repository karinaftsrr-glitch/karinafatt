/**
 * Complete Web Audio & Speech Synthesis Engine for Kids English Learning
 */

class SoundEngine {
  private audioCtx: AudioContext | null = null;
  private musicGainNode: GainNode | null = null;
  private soundGainNode: GainNode | null = null;
  private musicInterval: any = null;
  private isMusicPlaying: boolean = false;
  public isMusicEnabled: boolean = true;
  public isSoundEnabled: boolean = true;

  constructor() {
    // AudioContext will be initialized on first user interaction
  }

  private initContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
        this.musicGainNode = this.audioCtx.createGain();
        this.soundGainNode = this.audioCtx.createGain();
        this.musicGainNode.gain.value = 0.12; // gentle background music
        this.soundGainNode.gain.value = 0.28; // clear sound effects
        this.musicGainNode.connect(this.audioCtx.destination);
        this.soundGainNode.connect(this.audioCtx.destination);
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  // --- Sound Effects ---

  public playClick() {
    if (!this.isSoundEnabled) return;
    this.initContext();
    if (!this.audioCtx || !this.soundGainNode) return;

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();
    const now = this.audioCtx.currentTime;

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, now);
    osc.frequency.exponentialRampToValueAtTime(740, now + 0.08);

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    osc.connect(gain);
    gain.connect(this.soundGainNode);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  public playBoing() {
    if (!this.isSoundEnabled) return;
    this.initContext();
    if (!this.audioCtx || !this.soundGainNode) return;

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();
    const now = this.audioCtx.currentTime;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(260, now);
    osc.frequency.exponentialRampToValueAtTime(580, now + 0.12);
    osc.frequency.exponentialRampToValueAtTime(380, now + 0.25);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.28);

    osc.connect(gain);
    gain.connect(this.soundGainNode);
    osc.start(now);
    osc.stop(now + 0.3);
  }

  public playCorrect() {
    if (!this.isSoundEnabled) return;
    this.initContext();
    if (!this.audioCtx || !this.soundGainNode) return;

    const now = this.audioCtx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      if (!this.audioCtx || !this.soundGainNode) return;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      const startTime = now + idx * 0.09;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0.22, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.25);

      osc.connect(gain);
      gain.connect(this.soundGainNode);
      osc.start(startTime);
      osc.stop(startTime + 0.28);
    });
  }

  public playWrong() {
    if (!this.isSoundEnabled) return;
    this.initContext();
    if (!this.audioCtx || !this.soundGainNode) return;

    const now = this.audioCtx.currentTime;
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.linearRampToValueAtTime(240, now + 0.22);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

    osc.connect(gain);
    gain.connect(this.soundGainNode);
    osc.start(now);
    osc.stop(now + 0.25);
  }

  public playTick() {
    if (!this.isSoundEnabled) return;
    this.initContext();
    if (!this.audioCtx || !this.soundGainNode) return;

    const now = this.audioCtx.currentTime;
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, now);
    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.connect(gain);
    gain.connect(this.soundGainNode);
    osc.start(now);
    osc.stop(now + 0.05);
  }

  public playCountdown(isGo: boolean = false) {
    if (!this.isSoundEnabled) return;
    this.initContext();
    if (!this.audioCtx || !this.soundGainNode) return;

    const now = this.audioCtx.currentTime;
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = isGo ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(isGo ? 880 : 440, now);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (isGo ? 0.35 : 0.15));

    osc.connect(gain);
    gain.connect(this.soundGainNode);
    osc.start(now);
    osc.stop(now + (isGo ? 0.4 : 0.2));
  }

  public playVictory() {
    if (!this.isSoundEnabled) return;
    this.initContext();
    if (!this.audioCtx || !this.soundGainNode) return;

    const notes = [
      { f: 523.25, d: 0.15 },
      { f: 659.25, d: 0.15 },
      { f: 783.99, d: 0.15 },
      { f: 1046.5, d: 0.4 },
      { f: 880.0, d: 0.15 },
      { f: 1046.5, d: 0.6 },
    ];
    let offset = 0;
    const now = this.audioCtx.currentTime;
    notes.forEach((note) => {
      if (!this.audioCtx || !this.soundGainNode) return;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      const startTime = now + offset;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(note.f, startTime);

      gain.gain.setValueAtTime(0.25, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + note.d);

      osc.connect(gain);
      gain.connect(this.soundGainNode);
      osc.start(startTime);
      osc.stop(startTime + note.d + 0.05);

      offset += note.d * 0.95;
    });
  }

  // --- Voice / Speech Synthesis (Clear English Pronunciation) ---

  public speak(text: string, onEnd?: () => void) {
    if (!this.isSoundEnabled) {
      if (onEnd) onEnd();
      return;
    }
    if (!('speechSynthesis' in window)) {
      if (onEnd) onEnd();
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = 0.95; // child-friendly, clear pace
      utterance.pitch = 1.15; // cheerful clear pitch

      // Pick a good English voice if available
      const voices = window.speechSynthesis.getVoices();
      const englishVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Samantha') || v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Junior')));
      if (englishVoice) {
        utterance.voice = englishVoice;
      }

      utterance.onend = () => {
        if (onEnd) onEnd();
      };
      utterance.onerror = () => {
        if (onEnd) onEnd();
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error', e);
      if (onEnd) onEnd();
    }
  }

  public playFoodSound(foodName?: string, onComplete?: () => void) {
    this.playBoing();
    if (foodName) {
      this.speak(foodName, onComplete);
    } else if (onComplete) {
      onComplete();
    }
  }

  // Alias ensuring clean speech
  public playYumYum(foodName?: string, onComplete?: () => void) {
    this.playFoodSound(foodName, onComplete);
  }

  // --- Background Music Loop (Gentle marimba / toy pentatonic) ---

  public toggleMusic(enable?: boolean): boolean {
    if (enable !== undefined) {
      this.isMusicEnabled = enable;
    } else {
      this.isMusicEnabled = !this.isMusicEnabled;
    }

    if (this.isMusicEnabled) {
      this.startMusic();
    } else {
      this.stopMusic();
    }
    return this.isMusicEnabled;
  }

  public toggleSound(enable?: boolean): boolean {
    if (enable !== undefined) {
      this.isSoundEnabled = enable;
    } else {
      this.isSoundEnabled = !this.isSoundEnabled;
    }
    if (!this.isSoundEnabled && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    return this.isSoundEnabled;
  }

  public startMusic() {
    if (!this.isMusicEnabled || this.isMusicPlaying) return;
    this.initContext();
    if (!this.audioCtx || !this.musicGainNode) return;

    this.isMusicPlaying = true;
    
    // Playful pentatonic notes for kids (C, D, E, G, A)
    const melody = [
      523.25, 659.25, 587.33, 783.99,
      659.25, 523.25, 587.33, 440.00,
      523.25, 587.33, 659.25, 783.99,
      880.00, 783.99, 659.25, 523.25
    ];
    let noteIdx = 0;

    const playNextNote = () => {
      if (!this.isMusicPlaying || !this.isMusicEnabled || !this.audioCtx || !this.musicGainNode) return;
      
      const now = this.audioCtx.currentTime;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(melody[noteIdx % melody.length], now);

      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);

      osc.connect(gain);
      gain.connect(this.musicGainNode);
      osc.start(now);
      osc.stop(now + 0.4);

      noteIdx++;
    };

    // Trigger periodically every 350ms
    if (this.musicInterval) clearInterval(this.musicInterval);
    this.musicInterval = setInterval(playNextNote, 360);
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }
}

export const sound = new SoundEngine();
