import { FoodItem } from '../types';
import riceImg from '../assets/images/realistic_rice_bowl_1790813917504.jpg';
import omeletImg from '../assets/images/realistic_omelet_1790813933117.jpg';
import tofuImg from '../assets/images/realistic_tofu_cubes_1790813946384.jpg';
import noodlesImg from '../assets/images/realistic_noodles_1790813959820.jpg';
import meatballImg from '../assets/images/realistic_meatball_1790813970972.jpg';

export const FOOD_ITEMS: FoodItem[] = [
  {
    id: 'rice',
    name: 'Rice',
    indonesianName: 'Nasi',
    image: riceImg,
    color: '#38bdf8',
    borderColor: '#0284c7',
    bgColor: '#e0f2fe',
    textColor: '#0369a1',
    description: 'A warm bowl of fluffy white rice, staple food for every meal!',
    exampleSentence: 'I like rice.',
    clues: [
      'It is white and fluffy.',
      'Many people eat it with chicken or fish every day.',
      'It is cooked in a rice cooker.'
    ]
  },
  {
    id: 'omelet',
    name: 'Omelet',
    indonesianName: 'Telur Dadar',
    image: omeletImg,
    color: '#fbbf24',
    borderColor: '#d97706',
    bgColor: '#fef3c7',
    textColor: '#b45309',
    description: 'A delicious golden fluffy rolled egg with herbs!',
    exampleSentence: 'I like omelet.',
    clues: [
      'It is made from beaten eggs.',
      'It has a beautiful golden yellow color.',
      'It is fried in a pan and rolled up fluffy.'
    ]
  },
  {
    id: 'tofu',
    name: 'Tofu',
    indonesianName: 'Tahu',
    image: tofuImg,
    color: '#f59e0b',
    borderColor: '#b45309',
    bgColor: '#fef3c7',
    textColor: '#92400e',
    description: 'Healthy and crispy golden square cubes made of soybeans!',
    exampleSentence: 'I like tofu.',
    clues: [
      'It is shaped like little golden cubes or blocks.',
      'It is made from healthy soybeans.',
      'It is soft inside and crispy on the outside.'
    ]
  },
  {
    id: 'noodles',
    name: 'Noodles',
    indonesianName: 'Mie',
    image: noodlesImg,
    color: '#f97316',
    borderColor: '#c2410c',
    bgColor: '#ffedd5',
    textColor: '#9a3412',
    description: 'Yummy long curly noodles served in a warm tasty bowl with chopsticks!',
    exampleSentence: 'I like noodles.',
    clues: [
      'It is long, thin, and curly.',
      'You can slurp it with soup or eat it fried.',
      'You often eat it with a fork or chopsticks.'
    ]
  },
  {
    id: 'meatball',
    name: 'Meatball',
    indonesianName: 'Bakso',
    image: meatballImg,
    color: '#ef4444',
    borderColor: '#b91c1c',
    bgColor: '#fee2e2',
    textColor: '#991b1b',
    description: 'Bouncy round meatballs with savory soup and celery garnish!',
    exampleSentence: 'I like meatball.',
    clues: [
      'It has a round sphere shape like a small ball.',
      'It bounces on the spoon and tastes savory.',
      'It is made of seasoned ground beef or chicken.'
    ]
  }
];
