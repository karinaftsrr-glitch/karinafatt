import React, { useState, useEffect } from 'react';
import { NavTab, LearningProgress, Achievement } from './types';
import { sound } from './utils/audio';
import { Header } from './components/Header';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HalamanPembuka } from './components/HalamanPembuka';
import { TujuanPembelajaran } from './components/TujuanPembelajaran';
import { BahanAjar } from './components/BahanAjar';
import { Latihan } from './components/Latihan';
import { GameArena } from './components/GameArena';
import { KompetisiSkor } from './components/KompetisiSkor';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('pembuka');
  const [isMusicOn, setIsMusicOn] = useState<boolean>(false);
  const [isSoundOn, setIsSoundOn] = useState<boolean>(true);
  const [totalScore, setTotalScore] = useState<number>(0);

  const [progress, setProgress] = useState<LearningProgress>({
    vocabulary: 40,
    grammar: 20,
    practice: 0,
    games: 0,
    competition: 0,
  });

  const [achievements, setAchievements] = useState<Achievement[]>([
    {
      id: 'vocab_master',
      title: 'Vocabulary Master',
      description: 'Kenali 5 makanan 3D dan dengarkan suaranya.',
      iconType: 'star',
      unlocked: true,
    },
    {
      id: 'grammar_explorer',
      title: 'Grammar Explorer',
      description: 'Pahami perbedaan LIKE dan LIKES dengan benar.',
      iconType: 'target',
      unlocked: false,
    },
    {
      id: 'sentence_builder',
      title: 'Sentence Builder',
      description: 'Susun kalimat bahasa Inggris di Sentence Builder.',
      iconType: 'puzzle',
      unlocked: false,
    },
    {
      id: 'fast_answer',
      title: 'Fast Answer',
      description: 'Jawab pertanyaan cepat sebelum waktu habis.',
      iconType: 'zap',
      unlocked: false,
    },
    {
      id: 'game_champion',
      title: 'Game Champion',
      description: 'Menangkan putaran game atau kompetisi 3 pemain!',
      iconType: 'trophy',
      unlocked: false,
    },
  ]);

  // Audio Toggles
  const handleToggleMusic = () => {
    const nextState = !isMusicOn;
    setIsMusicOn(nextState);
    sound.toggleMusic(nextState);
  };

  const handleToggleSound = () => {
    const nextState = !isSoundOn;
    setIsSoundOn(nextState);
    sound.toggleSound(nextState);
  };

  // Reset System (Section 37)
  const handleResetAll = () => {
    setProgress({
      vocabulary: 0,
      grammar: 0,
      practice: 0,
      games: 0,
      competition: 0,
    });
    setTotalScore(0);
    setAchievements((prev) =>
      prev.map((ach) => ({
        ...ach,
        unlocked: false,
      }))
    );
    setActiveTab('pembuka');
  };

  const handleUnlockBadge = (badgeId: string) => {
    setAchievements((prev) =>
      prev.map((item) => (item.id === badgeId ? { ...item, unlocked: true } : item))
    );
  };

  const handleUpdateScore = (points: number) => {
    setTotalScore((prev) => prev + points);
  };

  const handleUpdateProgress = (key: keyof LearningProgress, val: number) => {
    setProgress((prev) => ({
      ...prev,
      [key]: Math.max(prev[key], val),
    }));
  };

  // Auto scroll to top when changing tab
  const handleTabChange = (tab: NavTab) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-sky-50/50 text-slate-800 font-bubble">
      {/* 1. Header (Identity & Controls) */}
      <Header
        onReset={handleResetAll}
        isMusicOn={isMusicOn}
        isSoundOn={isSoundOn}
        onToggleMusic={handleToggleMusic}
        onToggleSound={handleToggleSound}
      />

      {/* 2. Main Navigation Tabs */}
      <Navbar activeTab={activeTab} onTabChange={handleTabChange} />

      {/* 3. Main Content Views */}
      <main className="flex-1">
        {activeTab === 'pembuka' && (
          <HalamanPembuka
            onStartLearning={() => {
              handleUpdateProgress('vocabulary', 30);
              handleTabChange('tujuan');
            }}
          />
        )}

        {activeTab === 'tujuan' && (
          <TujuanPembelajaran
            onContinue={() => {
              handleTabChange('bahan-ajar');
            }}
          />
        )}

        {activeTab === 'bahan-ajar' && (
          <BahanAjar
            onCompleteBook={() => {
              handleUpdateProgress('vocabulary', 100);
              handleUpdateProgress('grammar', 80);
              handleUnlockBadge('vocab_master');
              handleTabChange('latihan');
            }}
            onUpdateProgress={handleUpdateProgress}
          />
        )}

        {activeTab === 'latihan' && (
          <Latihan
            onCompletePractice={() => {
              handleUpdateProgress('practice', 100);
              handleTabChange('games');
            }}
            onUpdateScore={handleUpdateScore}
            onUnlockBadge={handleUnlockBadge}
          />
        )}

        {activeTab === 'games' && (
          <GameArena
            onUpdateScore={handleUpdateScore}
            onUnlockBadge={handleUnlockBadge}
            onGoToCompetition={() => {
              handleUpdateProgress('games', 100);
              handleTabChange('skor');
            }}
          />
        )}

        {activeTab === 'skor' && (
          <KompetisiSkor
            progress={progress}
            achievements={achievements}
            totalScore={totalScore}
            onBackToLearning={() => handleTabChange('bahan-ajar')}
            onPlayAgain={() => {
              handleTabChange('pembuka');
            }}
            onProgressUpdate={handleUpdateProgress}
            onUnlockBadge={handleUnlockBadge}
          />
        )}
      </main>

      {/* 4. Footer */}
      <Footer />
    </div>
  );
}
