import React, { useState, useEffect, useRef } from 'react';
import { FoodId } from '../types';
import { FOOD_ITEMS } from '../data/foodData';
import { Food3DCanvas } from './Food3DCanvas';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  Gamepad2,
  Sparkles,
  Trophy,
  Volume2,
  CheckCircle2,
  RotateCcw,
  Zap,
  HelpCircle,
  ArrowRight,
  Timer
} from 'lucide-react';

interface GameArenaProps {
  onUpdateScore: (points: number) => void;
  onUnlockBadge: (badgeId: string) => void;
  onGoToCompetition: () => void;
}

type GameMode = 'wheel' | 'guess' | 'match' | 'fast';

export const GameArena: React.FC<GameArenaProps> = ({
  onUpdateScore,
  onUnlockBadge,
  onGoToCompetition,
}) => {
  const [activeGame, setActiveGame] = useState<GameMode>('wheel');
  const [gameScore, setGameScore] = useState<number>(0);

  // -------------------------------------------------------------
  // GAME 1: FOOD SPINNING WHEEL
  // -------------------------------------------------------------
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [wheelRotation, setWheelRotation] = useState<number>(0);
  const [landedFood, setLandedFood] = useState<FoodId | null>(null);
  const [wheelAnswer, setWheelAnswer] = useState<'yes' | 'no' | null>(null);

  const spinWheel = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setLandedFood(null);
    setWheelAnswer(null);
    sound.playClick();

    // 5 segments, 72 deg each
    const randomIndex = Math.floor(Math.random() * FOOD_ITEMS.length);
    const targetFood = FOOD_ITEMS[randomIndex];
    const extraSpins = 5 + Math.floor(Math.random() * 3); // 5 to 7 full rounds
    const segmentAngle = 360 / FOOD_ITEMS.length;
    // Align target food to top pointer (270 deg / top)
    const targetDegree = extraSpins * 360 + (randomIndex * segmentAngle) + segmentAngle / 2;

    setWheelRotation((prev) => prev + targetDegree);

    // Play ticking sound while spinning
    let ticks = 0;
    const tickInterval = setInterval(() => {
      sound.playTick();
      ticks++;
      if (ticks > 25) clearInterval(tickInterval);
    }, 120);

    setTimeout(() => {
      clearInterval(tickInterval);
      setIsSpinning(false);
      setLandedFood(targetFood.id);
      sound.playVictory();
      sound.playFoodSound(targetFood.name);
      onUnlockBadge('game_champion');
    }, 3200);
  };

  const handleWheelAnswer = (type: 'yes' | 'no') => {
    setWheelAnswer(type);
    sound.playCorrect();
    const sentence = type === 'yes' ? 'Yes, I do!' : "No, I don't.";
    sound.speak(sentence);
    confetti({ particleCount: 30, spread: 60 });
    setGameScore((s) => s + 25);
    onUpdateScore(25);
  };

  // -------------------------------------------------------------
  // GAME 2: GUESS THE FOOD (CLUES & MYSTERY)
  // -------------------------------------------------------------
  const guessLevels = [
    {
      foodId: 'noodles' as FoodId,
      clues: ['It is long and curly.', 'You can eat it with soup or fried.', 'What food is it?'],
      options: ['Noodles', 'Rice', 'Omelet', 'Meatball'],
    },
    {
      foodId: 'rice' as FoodId,
      clues: ['It is white and warm.', 'People in Indonesia eat it every day.', 'What food is it?'],
      options: ['Rice', 'Tofu', 'Meatball', 'Noodles'],
    },
    {
      foodId: 'tofu' as FoodId,
      clues: ['It is cut into golden cubes.', 'It is made of healthy soybeans.', 'What food is it?'],
      options: ['Tofu', 'Omelet', 'Meatball', 'Rice'],
    },
    {
      foodId: 'meatball' as FoodId,
      clues: ['It is round like a little ball.', 'It bounces and tastes savory in soup.', 'What food is it?'],
      options: ['Meatball', 'Noodles', 'Rice', 'Tofu'],
    },
    {
      foodId: 'omelet' as FoodId,
      clues: ['It is made from beaten eggs.', 'It has a fluffy golden yellow color.', 'What food is it?'],
      options: ['Omelet', 'Rice', 'Tofu', 'Meatball'],
    },
  ];

  const [guessIndex, setGuessIndex] = useState<number>(0);
  const [guessRevealed, setGuessRevealed] = useState<boolean>(false);
  const [guessChoice, setGuessChoice] = useState<string | null>(null);

  const handleGuess = (opt: string) => {
    if (guessChoice !== null) return;
    setGuessChoice(opt);
    const curr = guessLevels[guessIndex];
    if (opt.toLowerCase() === curr.foodId.toLowerCase()) {
      setGuessRevealed(true);
      sound.playCorrect();
      sound.playFoodSound(opt);
      confetti({ particleCount: 35, spread: 60 });
      setGameScore((s) => s + 30);
      onUpdateScore(30);
    } else {
      sound.playWrong();
    }
  };

  const nextGuess = () => {
    setGuessChoice(null);
    setGuessRevealed(false);
    setGuessIndex((prev) => (prev + 1) % guessLevels.length);
  };

  // -------------------------------------------------------------
  // GAME 3: MATCH THE FOOD (DRAG & DROP / TAP MATCH)
  // -------------------------------------------------------------
  const [matchedFoods, setMatchedFoods] = useState<Record<FoodId, boolean>>({
    rice: false,
    omelet: false,
    tofu: false,
    noodles: false,
    meatball: false,
  });
  const [activeSelectedFood, setActiveSelectedFood] = useState<FoodId | null>(null);

  const handleSelectFoodItem = (fId: FoodId) => {
    if (matchedFoods[fId]) return;
    sound.playClick();
    setActiveSelectedFood(fId);
  };

  const handleTargetWordTap = (targetWord: FoodId) => {
    if (!activeSelectedFood) return;
    if (activeSelectedFood === targetWord) {
      // Correct match!
      sound.playCorrect();
      sound.playFoodSound(targetWord);
      confetti({ particleCount: 25, spread: 50 });
      setMatchedFoods((prev) => ({ ...prev, [targetWord]: true }));
      setActiveSelectedFood(null);
      setGameScore((s) => s + 20);
      onUpdateScore(20);
    } else {
      sound.playWrong();
    }
  };

  const resetMatchGame = () => {
    sound.playClick();
    setMatchedFoods({
      rice: false,
      omelet: false,
      tofu: false,
      noodles: false,
      meatball: false,
    });
    setActiveSelectedFood(null);
  };

  // -------------------------------------------------------------
  // GAME 4: FASTEST ANSWER (COUNTDOWN TIMER)
  // -------------------------------------------------------------
  const fastQuestions = [
    {
      q: 'Does she like noodles?',
      foodId: 'noodles' as FoodId,
      options: ['Yes, she does.', 'Yes, she do.', 'No, she don’t.'],
      correct: 'Yes, she does.',
    },
    {
      q: 'I ___ rice.',
      foodId: 'rice' as FoodId,
      options: ['like', 'likes', 'liking'],
      correct: 'like',
    },
    {
      q: 'He ___ meatball.',
      foodId: 'meatball' as FoodId,
      options: ['likes', 'like', 'is like'],
      correct: 'likes',
    },
    {
      q: 'Do you like tofu?',
      foodId: 'tofu' as FoodId,
      options: ['Yes, I do.', 'Yes, I does.', 'No, I doesn’t.'],
      correct: 'Yes, I do.',
    },
  ];

  const [fastIndex, setFastIndex] = useState<number>(0);
  const [fastTimeLeft, setFastTimeLeft] = useState<number>(10);
  const [fastIsActive, setFastIsActive] = useState<boolean>(false);
  const [fastCountdown, setFastCountdown] = useState<number | null>(null);
  const [fastAnswer, setFastAnswer] = useState<string | null>(null);
  const timerRef = useRef<any>(null);

  const startFastGame = () => {
    sound.playClick();
    setFastAnswer(null);
    setFastCountdown(3);
    sound.playCountdown(false);

    let count = 3;
    const countInterval = setInterval(() => {
      count--;
      if (count > 0) {
        setFastCountdown(count);
        sound.playCountdown(false);
      } else {
        clearInterval(countInterval);
        setFastCountdown(0);
        sound.playCountdown(true); // "GO!"
        setTimeout(() => {
          setFastCountdown(null);
          setFastIsActive(true);
          setFastTimeLeft(10);
        }, 600);
      }
    }, 800);
  };

  useEffect(() => {
    if (fastIsActive && fastTimeLeft > 0) {
      timerRef.current = setInterval(() => {
        setFastTimeLeft((t) => {
          if (t <= 1) {
            clearInterval(timerRef.current);
            setFastIsActive(false);
            sound.playWrong();
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [fastIsActive, fastTimeLeft]);

  const handleFastAnswer = (opt: string) => {
    if (!fastIsActive || fastAnswer !== null) return;
    clearInterval(timerRef.current);
    setFastIsActive(false);
    setFastAnswer(opt);

    const curr = fastQuestions[fastIndex];
    if (opt === curr.correct) {
      sound.playCorrect();
      confetti({ particleCount: 35, spread: 60 });
      const speedBonus = fastTimeLeft * 5;
      const totalPoints = 20 + speedBonus;
      setGameScore((s) => s + totalPoints);
      onUpdateScore(totalPoints);
      onUnlockBadge('fast_answer');
    } else {
      sound.playWrong();
    }
  };

  const nextFastQuestion = () => {
    setFastIndex((prev) => (prev + 1) % fastQuestions.length);
    startFastGame();
  };

  return (
    <div className="py-6 sm:py-8 px-4 max-w-5xl mx-auto animate-fadeIn">
      {/* Game Arena Hero */}
      <div className="bg-gradient-to-r from-orange-400 via-amber-400 to-yellow-400 rounded-3xl p-6 sm:p-8 text-amber-950 shadow-xl mb-6 border-4 border-orange-300 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 bg-white/40 px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase mb-1">
            <Gamepad2 className="w-4 h-4 text-orange-900" />
            <span>GAME ARENA • READY TO PLAY?</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black font-bubble">
            GAME ARENA
          </h1>
          <p className="text-orange-950 text-xs sm:text-sm font-bold mt-1">
            Mainkan 4 game seru untuk menguji kosakata makanan dan tata bahasa!
          </p>
        </div>

        {/* Live Arena Score */}
        <div className="flex items-center gap-3 bg-white/70 backdrop-blur-md px-5 py-3 rounded-2xl border-2 border-white shadow-md">
          <Trophy className="w-8 h-8 text-amber-600 animate-bounce" />
          <div className="text-left">
            <span className="block text-[10px] font-extrabold uppercase text-amber-900">
              ARENA SCORE
            </span>
            <span className="text-2xl font-black text-amber-950 font-bubble">
              {gameScore} pts
            </span>
          </div>
        </div>
      </div>

      {/* Game Mode Selector Buttons */}
      <div className="flex flex-wrap items-center gap-2.5 mb-6">
        {[
          { id: 'wheel', label: '🎡 1. Spinning Wheel' },
          { id: 'guess', label: '❓ 2. Guess The Food' },
          { id: 'match', label: '🎯 3. Match The Food' },
          { id: 'fast', label: '⚡ 4. Fastest Answer' },
        ].map((g) => (
          <button
            key={g.id}
            onClick={() => {
              sound.playClick();
              setActiveGame(g.id as GameMode);
            }}
            className={`btn-bubble py-3 px-5 rounded-2xl text-xs sm:text-sm font-black border-2 transition-all ${
              activeGame === g.id
                ? 'bg-orange-500 text-white border-orange-600 scale-105 shadow-md'
                : 'bg-white text-slate-700 border-slate-200 hover:border-orange-300'
            }`}
          >
            {g.label}
          </button>
        ))}
      </div>

      {/* Main Game Stage Box */}
      <div className="bg-white rounded-3xl border-8 border-orange-200 shadow-xl p-6 sm:p-10 min-h-[500px] flex flex-col justify-between">
        {/* ================= GAME 1: SPINNING WHEEL ================= */}
        {activeGame === 'wheel' && (
          <div className="animate-fadeIn text-center">
            <span className="text-xs font-black bg-orange-100 text-orange-900 px-3 py-1 rounded-full uppercase">
              GAME 1 • FOOD SPINNING WHEEL
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 font-bubble mt-2">
              Putar roda dan jawab pertanyaannya!
            </h2>

            <div className="flex flex-col md:flex-row items-center justify-around gap-8 my-6">
              {/* Spinning Wheel Container */}
              <div className="relative flex flex-col items-center">
                {/* Pointer indicator */}
                <div className="w-0 h-0 border-l-[16px] border-l-transparent border-r-[16px] border-r-transparent border-t-[28px] border-t-rose-600 z-20 -mb-4 drop-shadow-md" />

                {/* The Wheel */}
                <div
                  style={{
                    transform: `rotate(${wheelRotation}deg)`,
                    transition: isSpinning ? 'transform 3.2s cubic-bezier(0.15, 0.9, 0.2, 1)' : 'none',
                  }}
                  className="w-64 h-64 sm:w-72 sm:h-72 rounded-full border-8 border-amber-300 shadow-2xl relative overflow-hidden flex items-center justify-center bg-amber-50"
                >
                  {/* Wheel slices using SVG */}
                  <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                    {FOOD_ITEMS.map((item, idx) => {
                      const angle = (360 / FOOD_ITEMS.length);
                      const startAngle = (idx * angle) * (Math.PI / 180);
                      const endAngle = ((idx + 1) * angle) * (Math.PI / 180);
                      const x1 = 50 + 50 * Math.cos(startAngle);
                      const y1 = 50 + 50 * Math.sin(startAngle);
                      const x2 = 50 + 50 * Math.cos(endAngle);
                      const y2 = 50 + 50 * Math.sin(endAngle);

                      const colors = ['#38bdf8', '#fbbf24', '#f59e0b', '#f97316', '#ef4444'];

                      return (
                        <path
                          key={item.id}
                          d={`M 50 50 L ${x1} ${y1} A 50 50 0 0 1 ${x2} ${y2} Z`}
                          fill={colors[idx % colors.length]}
                          stroke="#ffffff"
                          strokeWidth="1.5"
                        />
                      );
                    })}
                  </svg>

                  {/* Wheel Center Hub */}
                  <div className="absolute w-14 h-14 bg-white rounded-full border-4 border-amber-400 shadow-md flex items-center justify-center font-black text-xs text-amber-900 z-10 font-bubble">
                    SPIN
                  </div>
                </div>

                {/* Spin Button */}
                <button
                  onClick={spinWheel}
                  disabled={isSpinning}
                  className={`mt-6 btn-bubble py-3.5 px-10 rounded-2xl font-black text-lg border-3 ${
                    isSpinning
                      ? 'bg-slate-200 text-slate-400 border-slate-300 cursor-not-allowed'
                      : 'bg-amber-400 hover:bg-amber-300 text-amber-950 border-amber-500 shadow-lg'
                  }`}
                >
                  {isSpinning ? 'Memutar...' : '🎡 PUTAR RODA!'}
                </button>
              </div>

              {/* Result Stage when stopped */}
              <div className="flex flex-col items-center max-w-sm">
                {landedFood ? (
                  <div className="animate-pop flex flex-col items-center">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Roda Berhenti Di:
                    </span>
                    <Food3DCanvas foodId={landedFood} size="md" showCardBanner={true} />

                    <div className="my-2 text-xl sm:text-2xl font-black text-slate-800 font-bubble">
                      Do you like {landedFood}?
                    </div>

                    <div className="flex items-center gap-4 mt-2">
                      <button
                        onClick={() => handleWheelAnswer('yes')}
                        className={`btn-bubble py-2.5 px-6 rounded-2xl font-black text-sm border-2 ${
                          wheelAnswer === 'yes'
                            ? 'bg-emerald-500 text-white border-emerald-600'
                            : 'bg-white text-emerald-700 border-emerald-300'
                        }`}
                      >
                        YES (Yes, I do.)
                      </button>
                      <button
                        onClick={() => handleWheelAnswer('no')}
                        className={`btn-bubble py-2.5 px-6 rounded-2xl font-black text-sm border-2 ${
                          wheelAnswer === 'no'
                            ? 'bg-rose-500 text-white border-rose-600'
                            : 'bg-white text-rose-700 border-rose-300'
                        }`}
                      >
                        NO (No, I don't.)
                      </button>
                    </div>

                    {wheelAnswer && (
                      <div className="mt-3 text-xs font-bold text-emerald-700 bg-emerald-50 px-4 py-2 rounded-xl border border-emerald-200 animate-fadeIn">
                        +25 Points! Great job!
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-8 text-center text-slate-400">
                    <span className="text-4xl block mb-2">🎁</span>
                    <span className="text-sm font-bold">
                      Tekan tombol "PUTAR RODA" untuk mendapatkan makanan acak 3D!
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ================= GAME 2: GUESS THE FOOD ================= */}
        {activeGame === 'guess' && (
          <div className="animate-fadeIn text-center">
            <span className="text-xs font-black bg-purple-100 text-purple-900 px-3 py-1 rounded-full uppercase">
              GAME 2 • LEVEL {guessIndex + 1} OF {guessLevels.length}
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 font-bubble mt-2">
              Tebak Makanan Dari Petunjuk!
            </h2>

            <div className="flex flex-col md:flex-row items-center justify-around gap-6 my-6">
              {/* Mystery 3D Box / Revealed 3D Food */}
              <div className="flex flex-col items-center">
                {guessRevealed ? (
                  <div className="animate-pop flex flex-col items-center">
                    <Food3DCanvas
                      foodId={guessLevels[guessIndex].foodId}
                      size="lg"
                      showCardBanner={true}
                    />
                    <span className="mt-2 text-xl font-black text-emerald-700 uppercase font-bubble">
                      🎉 It is {guessLevels[guessIndex].foodId}!
                    </span>
                  </div>
                ) : (
                  <div className="w-56 h-56 rounded-3xl bg-gradient-to-br from-violet-200 to-indigo-300 border-4 border-violet-400 shadow-xl flex flex-col items-center justify-center p-4">
                    <span className="text-6xl animate-bounce-gentle">❓</span>
                    <span className="text-sm font-black text-violet-950 font-bubble mt-2">
                      MYSTERY FOOD 3D
                    </span>
                    <span className="text-[11px] font-bold text-violet-800">
                      Baca petunjuk di samping!
                    </span>
                  </div>
                )}
              </div>

              {/* Clues Box and Multiple Choice */}
              <div className="flex flex-col items-center md:items-start text-left max-w-md w-full">
                <div className="bg-sky-50 rounded-2xl p-4 border-2 border-sky-200 w-full mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black text-sky-800 uppercase flex items-center gap-1">
                      <HelpCircle className="w-4 h-4 text-sky-600" />
                      <span>CLUES (PETUNJUK):</span>
                    </span>
                    <button
                      onClick={() => sound.speak(guessLevels[guessIndex].clues.join(' '))}
                      className="text-xs font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>Dengar Petunjuk</span>
                    </button>
                  </div>

                  <ul className="space-y-1.5 text-sm font-bold text-slate-700">
                    {guessLevels[guessIndex].clues.map((c, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-amber-500">★</span>
                        <span>{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Choices */}
                <div className="grid grid-cols-2 gap-3 w-full">
                  {guessLevels[guessIndex].options.map((opt) => {
                    const isRight = opt.toLowerCase() === guessLevels[guessIndex].foodId.toLowerCase();
                    const isChosen = guessChoice === opt;

                    let style = 'bg-white border-slate-200 text-slate-800 hover:border-violet-300';
                    if (guessChoice !== null) {
                      if (isRight) style = 'bg-emerald-500 text-white border-emerald-600 shadow-md';
                      else if (isChosen) style = 'bg-rose-500 text-white border-rose-600';
                    }

                    return (
                      <button
                        key={opt}
                        onClick={() => handleGuess(opt)}
                        disabled={guessChoice !== null}
                        className={`btn-bubble py-3.5 px-4 rounded-2xl font-black text-base border-3 ${style}`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>

                {/* Next button */}
                {guessChoice !== null && (
                  <button
                    onClick={nextGuess}
                    className="mt-4 w-full btn-bubble py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-sm border-2 border-amber-500 flex items-center justify-center gap-2"
                  >
                    <span>Level Berikutnya</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ================= GAME 3: MATCH THE FOOD ================= */}
        {activeGame === 'match' && (
          <div className="animate-fadeIn text-center">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-black bg-emerald-100 text-emerald-900 px-3 py-1 rounded-full uppercase">
                GAME 3 • MATCH THE FOOD
              </span>
              <button
                onClick={resetMatchGame}
                className="btn-bubble flex items-center gap-1.5 py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-300"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Match</span>
              </button>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 font-bubble">
              Sentuh Makanan 3D ➔ Lalu Sentuh Kata yang Tepat!
            </h2>

            <div className="my-6 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              {/* Left Column: 3D Food Items */}
              <div className="flex flex-col gap-3">
                <span className="text-xs font-black text-slate-400 uppercase tracking-wider">
                  PILIH MAKANAN 3D:
                </span>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {FOOD_ITEMS.map((item) => {
                    const isMatched = matchedFoods[item.id];
                    const isSelected = activeSelectedFood === item.id;

                    return (
                      <div
                        key={item.id}
                        onClick={() => handleSelectFoodItem(item.id)}
                        className={`rounded-2xl p-2 border-3 flex flex-col items-center justify-center cursor-pointer transition-all ${
                          isMatched
                            ? 'bg-emerald-50 border-emerald-400 opacity-50 cursor-not-allowed'
                            : isSelected
                            ? 'bg-amber-100 border-amber-500 scale-105 shadow-md'
                            : 'bg-white border-slate-200 hover:border-sky-300'
                        }`}
                      >
                        <Food3DCanvas foodId={item.id} size="sm" interactive={!isMatched} />
                        {isMatched ? (
                          <span className="text-xs font-black text-emerald-600 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Done
                          </span>
                        ) : (
                          <span className="text-[11px] font-bold text-slate-600">
                            {isSelected ? 'Terpilih!' : 'Pilih'}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right Column: Word Targets */}
              <div className="flex flex-col gap-2.5">
                <span className="text-xs font-black text-slate-400 uppercase tracking-wider">
                  PASANGKAN KE KATA BAHASA INGGRIS:
                </span>
                {FOOD_ITEMS.map((item) => {
                  const isMatched = matchedFoods[item.id];
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleTargetWordTap(item.id)}
                      disabled={isMatched}
                      className={`btn-bubble py-3 px-6 rounded-2xl font-black text-lg border-3 flex items-center justify-between transition-all ${
                        isMatched
                          ? 'bg-emerald-500 text-white border-emerald-600 shadow-sm opacity-90'
                          : 'bg-white text-slate-800 border-slate-200 hover:border-amber-400'
                      }`}
                    >
                      <span className="tracking-wider uppercase">{item.name}</span>
                      {isMatched && <CheckCircle2 className="w-6 h-6" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ================= GAME 4: FASTEST ANSWER & BATTLE ================= */}
        {activeGame === 'fast' && (
          <div className="animate-fadeIn text-center">
            <span className="text-xs font-black bg-rose-100 text-rose-900 px-3 py-1 rounded-full uppercase">
              GAME 4 • BATTLE PALING CEPAT & BENAR
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 font-bubble mt-2">
              Jawab Secepat Mungkin untuk Poin Maksimal!
            </h2>

            {/* Multiplayer Battle Turn-based CTA Banner */}
            <div className="my-6 bg-gradient-to-r from-rose-500 via-orange-500 to-amber-500 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 text-left">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-3xl shrink-0">
                  👥
                </div>
                <div>
                  <div className="inline-block bg-white/25 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase mb-1">
                    MODE BATTLE 3 PEMAIN
                  </div>
                  <h3 className="text-xl font-black font-bubble">
                    Mau battle bergilir bersama teman?
                  </h3>
                  <p className="text-xs font-medium text-rose-50">
                    Semua pemain giliran menjawab soal yang sama ➔ Yang paling cepat & benar jadi pemenang ronde!
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  sound.playVictory();
                  onGoToCompetition();
                }}
                className="btn-bubble py-3 px-6 rounded-2xl bg-amber-300 hover:bg-amber-200 text-amber-950 font-black text-sm border-2 border-white shadow-lg whitespace-nowrap"
              >
                🏆 Mulai Battle Bergilir ➔
              </button>
            </div>

            {/* Countdown Overlay 3.. 2.. 1.. GO! */}
            {fastCountdown !== null && (
              <div className="my-10 flex flex-col items-center justify-center animate-pop">
                <span className="text-7xl sm:text-9xl font-black text-orange-500 font-bubble drop-shadow-md">
                  {fastCountdown === 0 ? 'GO!' : fastCountdown}
                </span>
                <span className="text-sm font-bold text-slate-400 mt-2">
                  Bersiaplah...
                </span>
              </div>
            )}

            {/* Not started stage */}
            {!fastIsActive && fastCountdown === null && fastAnswer === null && (
              <div className="my-8 flex flex-col items-center justify-center">
                <div className="w-20 h-20 rounded-full bg-orange-100 border-4 border-orange-300 flex items-center justify-center text-4xl mb-4 animate-bounce">
                  ⚡
                </div>
                <h3 className="text-xl font-black text-slate-800 font-bubble mb-2">
                  Latihan Kecepatan Solo
                </h3>
                <p className="text-xs sm:text-sm font-medium text-slate-500 max-w-sm mb-6">
                  Waktu berjalan 10 detik. Semakin cepat kamu menjawab dengan benar, semakin banyak bonus poin yang didapat!
                </p>
                <button
                  onClick={startFastGame}
                  className="btn-bubble py-4 px-10 rounded-3xl bg-orange-500 hover:bg-orange-400 text-white font-black text-xl border-3 border-orange-600 shadow-xl"
                >
                  MULAI SEKARANG!
                </button>
              </div>
            )}

            {/* Active Question with Timer Bar */}
            {fastIsActive && (
              <div className="my-6 max-w-lg mx-auto flex flex-col items-center">
                {/* Timer Bar */}
                <div className="w-full mb-4">
                  <div className="flex items-center justify-between text-xs font-black text-slate-600 mb-1">
                    <span className="flex items-center gap-1 text-orange-600">
                      <Timer className="w-4 h-4" /> Sisa Waktu
                    </span>
                    <span className="text-sm font-black text-orange-700">
                      {fastTimeLeft} Detik
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden border-2 border-slate-200">
                    <div
                      style={{ width: `${(fastTimeLeft / 10) * 100}%` }}
                      className={`h-full transition-all duration-1000 ${
                        fastTimeLeft <= 3 ? 'bg-rose-500 animate-pulse' : 'bg-orange-400'
                      }`}
                    />
                  </div>
                </div>

                <Food3DCanvas
                  foodId={fastQuestions[fastIndex].foodId}
                  size="md"
                />

                <div className="my-3 text-2xl sm:text-3xl font-black text-slate-900 font-bubble">
                  {fastQuestions[fastIndex].q}
                </div>

                {/* Options */}
                <div className="grid grid-cols-1 gap-2.5 w-full mt-2">
                  {fastQuestions[fastIndex].options.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => handleFastAnswer(opt)}
                      className="btn-bubble py-3.5 px-6 rounded-2xl bg-white hover:bg-orange-50 text-slate-800 font-black text-lg border-3 border-slate-200 hover:border-orange-400"
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Answer Result Display */}
            {fastAnswer !== null && (
              <div className="my-8 flex flex-col items-center animate-pop">
                {fastAnswer === fastQuestions[fastIndex].correct ? (
                  <div className="bg-emerald-50 border-3 border-emerald-300 rounded-3xl p-6 text-center max-w-md">
                    <span className="text-4xl block mb-2">🎉</span>
                    <span className="text-xl font-black text-emerald-950 font-bubble block">
                      Super Cepat & Tepat!
                    </span>
                    <span className="text-xs font-bold text-emerald-700 block mt-1">
                      Jawaban: "{fastQuestions[fastIndex].correct}"
                    </span>
                  </div>
                ) : (
                  <div className="bg-rose-50 border-3 border-rose-300 rounded-3xl p-6 text-center max-w-md">
                    <span className="text-4xl block mb-2">⏰</span>
                    <span className="text-xl font-black text-rose-950 font-bubble block">
                      {fastTimeLeft === 0 ? 'Waktu Habis!' : 'Hampir Tepat!'}
                    </span>
                    <span className="text-xs font-bold text-rose-700 block mt-1">
                      Jawaban benar: "{fastQuestions[fastIndex].correct}"
                    </span>
                  </div>
                )}

                <button
                  onClick={nextFastQuestion}
                  className="mt-6 btn-bubble py-3 px-8 rounded-2xl bg-orange-500 hover:bg-orange-400 text-white font-black text-base border-2 border-orange-600 shadow-md"
                >
                  Pertanyaan Tercepat Berikutnya →
                </button>
              </div>
            )}
          </div>
        )}

        {/* Bottom CTA: Go to 3-Player Competition & Score */}
        <div className="border-t-2 border-slate-100 pt-6 mt-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-500">
            <Trophy className="w-5 h-5 text-amber-500" />
            <span>Siap tanding bersama teman?</span>
          </div>

          <button
            onClick={() => {
              sound.playVictory();
              onGoToCompetition();
            }}
            className="btn-bubble flex items-center gap-2 py-3 px-7 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-black text-base border-2 border-rose-600 shadow-lg shadow-rose-200"
          >
            <span>Masuk ke 3-Player Competition & Skor</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
