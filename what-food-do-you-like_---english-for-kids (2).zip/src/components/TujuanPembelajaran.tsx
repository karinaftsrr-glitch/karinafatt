import React from 'react';
import { Target, CheckCircle2, Volume2, ArrowRight, BookOpen, Sparkles, Star } from 'lucide-react';
import { sound } from '../utils/audio';

interface TujuanPembelajaranProps {
  onContinue: () => void;
}

export const TujuanPembelajaran: React.FC<TujuanPembelajaranProps> = ({ onContinue }) => {
  const goals = [
    {
      id: 'vocab',
      icon: '🍜',
      badge: 'VOCABULARY',
      badgeColor: 'bg-sky-100 text-sky-800 border-sky-300',
      title: 'Mengenal 5 Kosakata Makanan',
      englishTarget: 'Recognize 5 Delicious Food Words',
      details: ['rice (nasi)', 'omelet (telur dadar)', 'tofu (tahu)', 'noodles (mie)', 'meatball (bakso)'],
      audioSentence: 'Rice, omelet, tofu, noodles, meatball.'
    },
    {
      id: 'asking',
      icon: '❓',
      badge: 'ASKING',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      title: 'Menanyakan Makanan Kesukaan',
      englishTarget: 'Ask Questions about Food Likes',
      details: ['What food do you like?', "What's your favorite food?"],
      audioSentence: "What food do you like? What's your favorite food?"
    },
    {
      id: 'answering',
      icon: '💬',
      badge: 'ANSWERING',
      badgeColor: 'bg-amber-100 text-amber-900 border-amber-300',
      title: 'Menjawab Kesukaan Makanan',
      englishTarget: 'State What Food You Like',
      details: ['I like noodles.', 'My favorite food is rice.'],
      audioSentence: 'I like noodles. My favorite food is rice.'
    },
    {
      id: 'grammar',
      icon: '⚖️',
      badge: 'GRAMMAR',
      badgeColor: 'bg-violet-100 text-violet-800 border-violet-300',
      title: 'Aturan Tata Bahasa: LIKE vs LIKES',
      englishTarget: 'Use Correct Subject-Verb Agreement',
      details: ['I / You / We / They + LIKE', 'He / She + LIKES (ada tambahan -s)'],
      audioSentence: 'I like rice. She likes noodles.'
    },
    {
      id: 'questions',
      icon: '🙋',
      badge: 'QUESTIONS',
      badgeColor: 'bg-orange-100 text-orange-900 border-orange-300',
      title: 'Pertanyaan Do & Does',
      englishTarget: 'Ask and Answer with Do & Does',
      details: ['Do you like rice? -> Yes, I do. / No, I don\'t.', 'Does she like noodles? -> Yes, she does.'],
      audioSentence: 'Do you like noodles? Yes, I do.'
    },
    {
      id: 'listening',
      icon: '🎧',
      badge: 'LISTENING',
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
      title: 'Mendengarkan dan Memahami',
      englishTarget: 'Listen and Understand Food Sentences',
      details: ['Mendengarkan pengucapan kata', 'Memahami kalimat pendek dengan benar'],
      audioSentence: 'Listen and repeat after the teacher!'
    },
  ];

  return (
    <div className="py-6 sm:py-8 px-4 max-w-7xl mx-auto animate-fadeIn">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-400 via-teal-400 to-sky-400 rounded-3xl p-6 sm:p-8 text-white shadow-xl mb-8 border-4 border-emerald-300 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4 text-center md:text-left">
          <div className="w-16 h-16 rounded-3xl bg-white/20 backdrop-blur-md border-2 border-white/40 flex items-center justify-center text-4xl shadow-inner shrink-0">
            🎯
          </div>
          <div>
            <div className="inline-flex items-center gap-1.5 bg-white/25 px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>LEARNING OBJECTIVES & GUIDELINES</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black font-bubble drop-shadow-xs">
              TARGET & PANDUAN BELAJAR
            </h1>
            <p className="text-emerald-50 text-sm sm:text-base font-medium mt-1">
              Yuk lihat apa saja yang akan kamu kuasai dalam pelajaran seru ini!
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            onContinue();
          }}
          className="btn-bubble flex items-center gap-2 py-3 px-6 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-base shadow-lg border-2 border-amber-300 whitespace-nowrap"
        >
          <span>Mulai Buku Belajar</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>

      {/* Target Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {goals.map((goal, idx) => (
          <div
            key={goal.id}
            className="bg-white rounded-3xl p-6 border-4 border-slate-100 hover:border-emerald-300 shadow-md hover:shadow-xl transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-4xl p-2 bg-emerald-50 rounded-2xl border border-emerald-100">
                  {goal.icon}
                </span>
                <span className={`text-xs font-black px-3 py-1 rounded-full border ${goal.badgeColor}`}>
                  {goal.badge}
                </span>
              </div>

              <h2 className="text-xl font-black text-slate-800 font-bubble mb-1">
                {idx + 1}. {goal.title}
              </h2>
              <p className="text-xs font-bold text-emerald-600 mb-4">
                {goal.englishTarget}
              </p>

              <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-100 space-y-2 mb-4">
                {goal.details.map((detail, dIdx) => (
                  <div key={dIdx} className="flex items-start gap-2 text-xs sm:text-sm font-semibold text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{detail}</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => sound.speak(goal.audioSentence)}
              className="w-full btn-bubble flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs sm:text-sm font-bold border-2 border-emerald-200 transition-colors"
            >
              <Volume2 className="w-4 h-4 text-emerald-600" />
              <span>Dengarkan Contoh Audio</span>
            </button>
          </div>
        ))}
      </div>

      {/* Next Step Box */}
      <div className="bg-sky-50 rounded-3xl p-6 border-4 border-sky-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-sky-200 flex items-center justify-center text-sky-800 font-black text-xl shrink-0">
            📖
          </div>
          <div>
            <h3 className="text-lg font-black text-sky-950 font-bubble">
              Siap membaca Buku Belajar Siswa?
            </h3>
            <p className="text-xs sm:text-sm font-semibold text-sky-700">
              Pelajari Bab 1 hingga Bab 6 lengkap dengan animasi 3D makanan dan pengucapan asli!
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            onContinue();
          }}
          className="btn-bubble flex items-center gap-2 py-3 px-8 rounded-2xl bg-sky-500 hover:bg-sky-400 text-white font-black text-base shadow-md border-2 border-sky-600"
        >
          <BookOpen className="w-5 h-5" />
          <span>Buka Bahan Ajar (Bab 1)</span>
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
