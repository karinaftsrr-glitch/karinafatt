import React from 'react';
import { BookOpen, Sparkles, Star, Trophy } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-16 bg-white border-t-4 border-amber-300 py-8 px-4 text-center">
      <div className="max-w-4xl mx-auto flex flex-col items-center justify-center gap-3">
        <div className="flex items-center gap-2 text-2xl font-black text-amber-950 font-bubble">
          <span>🍜</span>
          <span>WHAT FOOD DO YOU LIKE?</span>
          <span>✨</span>
        </div>

        <p className="text-sm sm:text-base font-bold text-sky-700 font-bubble">
          English Learning Website for Kids
        </p>

        <div className="inline-flex items-center gap-3 bg-amber-100 text-amber-950 font-black text-xs sm:text-sm px-5 py-1.5 rounded-full border border-amber-300">
          <span>Learn</span>
          <span>•</span>
          <span>Practice</span>
          <span>•</span>
          <span>Play</span>
          <span>•</span>
          <span>Compete</span>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 mt-2">
          <span>Digital Textbook</span>
          <span>•</span>
          <span>3D Food World</span>
          <span>•</span>
          <span>Elementary School English</span>
        </div>
      </div>
    </footer>
  );
};
