import React, { useState } from 'react';
import { FoodId, NavTab } from '../types';
import { FOOD_ITEMS } from '../data/foodData';
import { Food3DCanvas } from './Food3DCanvas';
import { sound } from '../utils/audio';
import { Sparkles, ArrowRight, Star, BookOpen, Volume2 } from 'lucide-react';

interface HalamanPembukaProps {
  onStartLearning: () => void;
}

export const HalamanPembuka: React.FC<HalamanPembukaProps> = ({ onStartLearning }) => {
  const [selectedFood, setSelectedFood] = useState<FoodId | null>(null);

  const handleStart = () => {
    sound.playVictory();
    sound.speak("Let's learn English about food!");
    onStartLearning();
  };

  const handleFoodTap = (foodId: FoodId) => {
    setSelectedFood(foodId);
    const item = FOOD_ITEMS.find(f => f.id === foodId);
    if (item) {
      sound.playFoodSound(item.name);
    }
  };

  return (
    <div className="py-6 sm:py-10 px-4 max-w-7xl mx-auto animate-fadeIn">
      {/* Interactive Digital Book Cover Container */}
      <div className="relative bg-gradient-to-br from-amber-50 via-sky-50 to-orange-50 border-8 border-amber-300 rounded-[2.5rem] p-6 sm:p-10 shadow-2xl overflow-hidden">
        {/* Playful Floating Background Shapes (stars, badges, puzzle patterns - NO HEARTS) */}
        <div className="absolute top-6 left-8 text-amber-300 opacity-60 text-4xl animate-bounce-gentle">⭐</div>
        <div className="absolute top-16 right-12 text-sky-300 opacity-70 text-5xl animate-spin-slow">🌟</div>
        <div className="absolute bottom-8 left-12 text-orange-300 opacity-60 text-4xl animate-pulse">🎯</div>
        <div className="absolute bottom-12 right-20 text-emerald-300 opacity-60 text-4xl animate-bounce-gentle">🧩</div>

        {/* Top Header Badge */}
        <div className="flex justify-center mb-4">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-400 to-orange-400 text-amber-950 font-black px-6 py-2 rounded-full shadow-md text-sm sm:text-base border-2 border-white tracking-wider uppercase">
            <BookOpen className="w-5 h-5 text-amber-900" />
            <span>ENGLISH FOR ELEMENTARY STUDENTS</span>
            <Sparkles className="w-4 h-4 text-white animate-spin" />
          </div>
        </div>

        {/* Hero Title & Subtitle */}
        <div className="text-center max-w-3xl mx-auto mb-8">
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black text-amber-950 font-bubble tracking-tight drop-shadow-xs">
            WHAT FOOD DO YOU LIKE?
          </h1>
          <p className="mt-3 text-xl sm:text-2xl font-bold text-sky-700 font-bubble">
            Let's learn English about food! 🍽️
          </p>
          <p className="text-sm sm:text-base font-semibold text-slate-500 mt-1">
            Food • Likes • Simple Questions • Interactive 3D World
          </p>
        </div>

        {/* Interactive 3D Food Showcase (All 5 Main Foods) */}
        <div className="bg-white/80 backdrop-blur-md rounded-3xl p-4 sm:p-8 border-4 border-sky-200 shadow-xl mb-8">
          <div className="text-center mb-4">
            <span className="inline-flex items-center gap-2 bg-sky-100 text-sky-800 font-bold px-4 py-1.5 rounded-full text-sm border border-sky-300">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Tap any 3D food below to hear it react!</span>
              <Volume2 className="w-4 h-4 text-sky-600" />
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 sm:gap-6 justify-items-center">
            {FOOD_ITEMS.map((food) => {
              const isChosen = selectedFood === food.id;
              return (
                <div
                  key={food.id}
                  onClick={() => handleFoodTap(food.id)}
                  className={`group relative flex flex-col items-center bg-white/95 rounded-3xl p-3 sm:p-4 border-4 transition-all duration-200 cursor-pointer w-full max-w-[200px] ${
                    isChosen
                      ? 'border-amber-400 ring-4 ring-amber-200 -translate-y-2 shadow-xl'
                      : 'border-slate-100 hover:border-sky-300 shadow-md hover:-translate-y-1 hover:shadow-lg'
                  }`}
                >
                  {/* 3D Model */}
                  <div className="w-full flex justify-center">
                    <Food3DCanvas
                      foodId={food.id}
                      size="md"
                      interactive={true}
                      showCardBanner={true}
                      onClick={() => handleFoodTap(food.id)}
                    />
                  </div>

                  {/* Food Name & Indonesian */}
                  <div className="mt-2 text-center">
                    <span className="block text-lg font-black text-slate-800 tracking-wide uppercase">
                      {food.name}
                    </span>
                    <span className="block text-xs font-semibold text-slate-400">
                      ({food.indonesianName})
                    </span>
                  </div>

                  {/* Bubble Prompt */}
                  <div className="mt-2 w-full text-center bg-sky-50 rounded-xl py-1 px-2 border border-sky-100 group-hover:bg-amber-50 group-hover:border-amber-200 transition-colors">
                    <span className="text-[11px] font-bold text-sky-700 group-hover:text-amber-800">
                      {food.exampleSentence}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Big Start Learning CTA Button */}
        <div className="flex flex-col items-center justify-center gap-3">
          <button
            onClick={handleStart}
            className="btn-bubble flex items-center gap-3 py-4 sm:py-5 px-8 sm:px-12 rounded-3xl bg-gradient-to-r from-amber-400 via-orange-400 to-amber-500 hover:from-amber-500 hover:to-orange-500 text-amber-950 font-black text-xl sm:text-2xl shadow-xl border-4 border-amber-300 tracking-wide transform hover:scale-105 active:scale-95 transition-all"
          >
            <Star className="w-7 h-7 fill-amber-300 text-amber-950 animate-bounce" />
            <span>START LEARNING</span>
            <ArrowRight className="w-7 h-7" />
          </button>

          <p className="text-xs sm:text-sm font-semibold text-slate-500 text-center">
            Click Start to explore Learning Targets, Digital Textbook, Practice Zone & Games!
          </p>
        </div>
      </div>
    </div>
  );
};
