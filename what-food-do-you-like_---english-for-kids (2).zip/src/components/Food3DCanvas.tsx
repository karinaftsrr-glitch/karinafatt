import React, { useState, useRef } from 'react';
import { FoodId } from '../types';
import { FOOD_ITEMS } from '../data/foodData';
import { sound } from '../utils/audio';

interface Food3DCanvasProps {
  foodId: FoodId;
  size?: 'sm' | 'md' | 'lg' | 'hero';
  autoRotate?: boolean;
  interactive?: boolean;
  onClick?: (foodId: FoodId) => void;
  showCardBanner?: boolean;
}

export const Food3DCanvas: React.FC<Food3DCanvasProps> = ({
  foodId,
  size = 'md',
  interactive = true,
  onClick,
  showCardBanner = false,
}) => {
  const [isBouncing, setIsBouncing] = useState<boolean>(false);
  const [activeBanner, setActiveBanner] = useState<boolean>(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const foodItem = FOOD_ITEMS.find((f) => f.id === foodId) || FOOD_ITEMS[0];

  // Dimensions
  const getSizeStyles = () => {
    switch (size) {
      case 'sm':
        return {
          wrapper: 'w-24 h-24 sm:w-28 sm:h-28',
          img: 'w-20 h-20 sm:w-24 sm:h-24',
          shadow: 'shadow-md',
        };
      case 'md':
        return {
          wrapper: 'w-40 h-40 sm:w-48 sm:h-48',
          img: 'w-36 h-36 sm:w-44 sm:h-44',
          shadow: 'shadow-lg',
        };
      case 'lg':
        return {
          wrapper: 'w-56 h-56 sm:w-64 sm:h-64',
          img: 'w-52 h-52 sm:w-60 sm:h-60',
          shadow: 'shadow-xl',
        };
      case 'hero':
        return {
          wrapper: 'w-64 h-64 sm:w-76 sm:h-76',
          img: 'w-60 h-60 sm:w-72 sm:h-72',
          shadow: 'shadow-2xl',
        };
    }
  };

  const dim = getSizeStyles();

  // 3D Perspective Tilt on Pointer Move
  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!interactive || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = ((y - centerY) / centerY) * -16;
    const rotateY = ((x - centerX) / centerX) * 16;
    setTilt({ x: rotateX, y: rotateY });
  };

  const handlePointerLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  // Click / Tap Action: Pops, Bounces, Speaks Clear English
  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!interactive) return;

    setIsBouncing(true);
    setTimeout(() => setIsBouncing(false), 800);

    sound.playFoodSound(foodItem.name);

    if (showCardBanner) {
      setActiveBanner(true);
      setTimeout(() => setActiveBanner(false), 2500);
    }

    if (onClick) {
      onClick(foodId);
    }
  };

  return (
    <div className="relative inline-flex flex-col items-center justify-center select-none group">
      {/* 3D Realistic Food Container */}
      <div
        ref={cardRef}
        onClick={handleClick}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
        style={{
          perspective: '800px',
          transformStyle: 'preserve-3d',
        }}
        className={`relative ${dim.wrapper} flex items-center justify-center cursor-pointer transition-transform duration-200`}
        title={`Click to listen to "${foodItem.name}"`}
      >
        {/* Realistic 3D Tilt Layer */}
        <div
          style={{
            transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg) translateZ(10px)`,
            transition: tilt.x === 0 && tilt.y === 0 ? 'all 0.5s ease' : 'none',
          }}
          className={`relative rounded-3xl p-2 bg-gradient-to-b from-white to-slate-50 border-4 border-white shadow-xl hover:shadow-2xl transition-shadow flex items-center justify-center ${
            isBouncing ? 'animate-pop' : ''
          }`}
        >
          {/* Photorealistic 3D Rendered Image */}
          <img
            src={foodItem.image}
            alt={foodItem.name}
            className={`${dim.img} object-cover rounded-2xl drop-shadow-md transition-transform duration-300 group-hover:scale-105`}
            draggable={false}
          />

          {/* Realistic Gloss Highlights */}
          <div className="absolute inset-2 rounded-2xl pointer-events-none bg-gradient-to-tr from-transparent via-white/10 to-white/40 opacity-70" />

          {/* Contact Depth Shadow */}
          <div className="absolute -bottom-2 w-3/4 h-3 bg-slate-900/15 rounded-full blur-xs pointer-events-none" />
        </div>
      </div>

      {/* Floating Sparkles when clicked */}
      {isBouncing && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-10">
          <span className="absolute -top-2 left-2 text-2xl animate-ping">✨</span>
          <span className="absolute top-1 -right-2 text-xl animate-bounce">⭐</span>
          <span className="absolute bottom-4 left-0 text-xl animate-bounce">✨</span>
        </div>
      )}

      {/* Interactive Speech Banner (Clear English Pronunciation) */}
      {activeBanner && (
        <div className="absolute -top-10 z-20 bg-sky-500 text-white font-extrabold px-3 py-1 rounded-full shadow-lg border-2 border-white animate-pop flex items-center gap-1.5 whitespace-nowrap text-xs">
          <span>🔊</span>
          <span>{foodItem.name} • {foodItem.exampleSentence}</span>
        </div>
      )}
    </div>
  );
};
