import React from 'react';
import { NavTab } from '../types';
import { Home, Target, BookOpen, Edit3, Gamepad2, Trophy, ChevronRight } from 'lucide-react';
import { sound } from '../utils/audio';

interface NavbarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, onTabChange }) => {
  const tabs: { id: NavTab; label: string; enSubtitle: string; icon: React.ReactNode; num: number; color: string }[] = [
    {
      id: 'pembuka',
      label: 'Halaman Pembuka',
      enSubtitle: 'OPEN',
      icon: <Home className="w-5 h-5" />,
      num: 1,
      color: 'bg-amber-400 text-amber-950 border-amber-500',
    },
    {
      id: 'tujuan',
      label: 'Tujuan Pembelajaran',
      enSubtitle: 'TARGET',
      icon: <Target className="w-5 h-5" />,
      num: 2,
      color: 'bg-emerald-400 text-emerald-950 border-emerald-500',
    },
    {
      id: 'bahan-ajar',
      label: 'Bahan Ajar',
      enSubtitle: 'LEARN',
      icon: <BookOpen className="w-5 h-5" />,
      num: 3,
      color: 'bg-sky-400 text-sky-950 border-sky-500',
    },
    {
      id: 'latihan',
      label: 'Latihan',
      enSubtitle: 'PRACTICE',
      icon: <Edit3 className="w-5 h-5" />,
      num: 4,
      color: 'bg-violet-400 text-violet-950 border-violet-500',
    },
    {
      id: 'games',
      label: 'Games',
      enSubtitle: 'PLAY',
      icon: <Gamepad2 className="w-5 h-5" />,
      num: 5,
      color: 'bg-orange-400 text-orange-950 border-orange-500',
    },
    {
      id: 'skor',
      label: 'Skor & Kompetisi',
      enSubtitle: 'SCORE',
      icon: <Trophy className="w-5 h-5" />,
      num: 6,
      color: 'bg-rose-400 text-rose-950 border-rose-500',
    },
  ];

  return (
    <nav className="bg-sky-100/70 border-b border-sky-200 py-2.5 px-4 sticky top-[73px] z-30 shadow-xs overflow-x-auto">
      <div className="max-w-7xl mx-auto flex items-center justify-between min-w-max gap-2 md:gap-3">
        {tabs.map((tab, idx) => {
          const isActive = activeTab === tab.id;
          return (
            <React.Fragment key={tab.id}>
              <button
                onClick={() => {
                  sound.playClick();
                  onTabChange(tab.id);
                }}
                className={`btn-bubble flex items-center gap-2 py-2 px-3.5 rounded-2xl font-bold transition-all border-2 text-xs sm:text-sm whitespace-nowrap ${
                  isActive
                    ? `${tab.color} shadow-md scale-105 ring-2 ring-white`
                    : 'bg-white text-slate-700 border-slate-200 hover:border-sky-300 hover:bg-sky-50'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black ${
                    isActive ? 'bg-white/90 text-slate-900' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {tab.num}
                </span>
                <span>{tab.icon}</span>
                <div className="flex flex-col text-left leading-tight">
                  <span>{tab.label}</span>
                  <span className={`text-[10px] tracking-wider font-extrabold ${isActive ? 'opacity-85' : 'text-slate-400'}`}>
                    {tab.enSubtitle}
                  </span>
                </div>
              </button>

              {idx < tabs.length - 1 && (
                <ChevronRight className="w-4 h-4 text-sky-300 hidden xl:block shrink-0" />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </nav>
  );
};
