import React, { useState } from 'react';
import { FoodId } from '../types';
import { FOOD_ITEMS } from '../data/foodData';
import { Food3DCanvas } from './Food3DCanvas';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  XCircle,
  Volume2,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Star,
  Check,
  Award
} from 'lucide-react';

interface LatihanProps {
  onCompletePractice: () => void;
  onUpdateScore: (points: number) => void;
  onUnlockBadge: (badgeId: string) => void;
}

type PracticeTab = 'p1' | 'p2' | 'p3' | 'p4' | 'p5' | 'builder';

export const Latihan: React.FC<LatihanProps> = ({
  onCompletePractice,
  onUpdateScore,
  onUnlockBadge,
}) => {
  const [activeSection, setActiveSection] = useState<PracticeTab>('p1');
  const [starsEarned, setStarsEarned] = useState<number>(0);

  // --- Practice 1: Choose the Food ---
  const [p1Index, setP1Index] = useState<number>(0);
  const [p1Selected, setP1Selected] = useState<string | null>(null);
  const [p1IsCorrect, setP1IsCorrect] = useState<boolean | null>(null);

  const p1Questions: { foodId: FoodId; correct: string; options: string[] }[] = [
    { foodId: 'noodles', correct: 'Noodles', options: ['Noodles', 'Rice', 'Tofu', 'Meatball'] },
    { foodId: 'omelet', correct: 'Omelet', options: ['Meatball', 'Omelet', 'Rice', 'Noodles'] },
    { foodId: 'tofu', correct: 'Tofu', options: ['Tofu', 'Omelet', 'Noodles', 'Rice'] },
    { foodId: 'meatball', correct: 'Meatball', options: ['Rice', 'Tofu', 'Meatball', 'Omelet'] },
    { foodId: 'rice', correct: 'Rice', options: ['Omelet', 'Noodles', 'Tofu', 'Rice'] },
  ];

  const handleP1Answer = (option: string) => {
    if (p1Selected !== null) return;
    setP1Selected(option);
    const curr = p1Questions[p1Index];
    if (option === curr.correct) {
      setP1IsCorrect(true);
      sound.playCorrect();
      sound.playFoodSound(curr.correct);
      confetti({ particleCount: 30, spread: 60, origin: { y: 0.6 } });
      setStarsEarned((s) => s + 1);
      onUpdateScore(20);
    } else {
      setP1IsCorrect(false);
      sound.playWrong();
    }
  };

  const nextP1 = () => {
    setP1Selected(null);
    setP1IsCorrect(null);
    setP1Index((prev) => (prev + 1) % p1Questions.length);
  };

  // --- Practice 2: Complete the Sentence (LIKE vs LIKES) ---
  const [p2Index, setP2Index] = useState<number>(0);
  const [p2Answer, setP2Answer] = useState<string | null>(null);

  const p2Questions = [
    { sentence: 'I ___ rice.', subject: 'I', answer: 'LIKE', food: 'rice' as FoodId },
    { sentence: 'She ___ noodles.', subject: 'She', answer: 'LIKES', food: 'noodles' as FoodId },
    { sentence: 'We ___ tofu.', subject: 'We', answer: 'LIKE', food: 'tofu' as FoodId },
    { sentence: 'He ___ meatball.', subject: 'He', answer: 'LIKES', food: 'meatball' as FoodId },
    { sentence: 'They ___ omelet.', subject: 'They', answer: 'LIKE', food: 'omelet' as FoodId },
  ];

  const handleP2Answer = (choice: string) => {
    if (p2Answer !== null) return;
    const curr = p2Questions[p2Index];
    setP2Answer(choice);
    if (choice === curr.answer) {
      sound.playCorrect();
      confetti({ particleCount: 25, spread: 50 });
      setStarsEarned((s) => s + 1);
      onUpdateScore(20);
      onUnlockBadge('grammar_explorer');
    } else {
      sound.playWrong();
    }
  };

  const nextP2 = () => {
    setP2Answer(null);
    setP2Index((prev) => (prev + 1) % p2Questions.length);
  };

  // --- Practice 3: Choose the Correct Sentence ---
  const [p3Index, setP3Index] = useState<number>(0);
  const [p3Selected, setP3Selected] = useState<number | null>(null);

  const p3Questions = [
    {
      foodId: 'noodles' as FoodId,
      options: ['She like noodles.', 'She likes noodles.'],
      correctIndex: 1,
      explanation: 'Gunakan "likes" untuk subjek She!',
    },
    {
      foodId: 'rice' as FoodId,
      options: ['I likes rice.', 'I like rice.'],
      correctIndex: 1,
      explanation: 'Gunakan "like" untuk subjek I!',
    },
    {
      foodId: 'tofu' as FoodId,
      options: ['He likes tofu.', 'He like tofu.'],
      correctIndex: 0,
      explanation: 'Gunakan "likes" untuk subjek He!',
    },
    {
      foodId: 'meatball' as FoodId,
      options: ['They likes meatball.', 'They like meatball.'],
      correctIndex: 1,
      explanation: 'Gunakan "like" untuk subjek They!',
    },
  ];

  const handleP3Answer = (idx: number) => {
    if (p3Selected !== null) return;
    setP3Selected(idx);
    const curr = p3Questions[p3Index];
    if (idx === curr.correctIndex) {
      sound.playCorrect();
      confetti({ particleCount: 30, spread: 60 });
      setStarsEarned((s) => s + 1);
      onUpdateScore(20);
    } else {
      sound.playWrong();
    }
  };

  const nextP3 = () => {
    setP3Selected(null);
    setP3Index((prev) => (prev + 1) % p3Questions.length);
  };

  // --- Practice 4: Do you like? ---
  const [p4Index, setP4Index] = useState<number>(0);
  const [p4Answer, setP4Answer] = useState<'yes' | 'no' | null>(null);

  const p4Questions: { foodId: FoodId; question: string }[] = [
    { foodId: 'tofu', question: 'Do you like tofu?' },
    { foodId: 'omelet', question: 'Do you like omelet?' },
    { foodId: 'noodles', question: 'Do you like noodles?' },
    { foodId: 'meatball', question: 'Do you like meatball?' },
    { foodId: 'rice', question: 'Do you like rice?' },
  ];

  const handleP4Answer = (type: 'yes' | 'no') => {
    setP4Answer(type);
    sound.playCorrect();
    const sentence = type === 'yes' ? 'Yes, I do!' : "No, I don't.";
    sound.speak(sentence);
    setStarsEarned((s) => s + 1);
    onUpdateScore(15);
  };

  const nextP4 = () => {
    setP4Answer(null);
    setP4Index((prev) => (prev + 1) % p4Questions.length);
  };

  // --- Practice 5: Does she / he like? ---
  const [p5Index, setP5Index] = useState<number>(0);
  const [p5Selected, setP5Selected] = useState<string | null>(null);

  const p5Questions = [
    {
      character: '👧 Sinta',
      avatarEmoji: '👧',
      foodId: 'noodles' as FoodId,
      question: 'Does she like noodles?',
      clue: 'Sinta is smiling and giving a thumbs up! 👍',
      correct: 'Yes, she does.',
      options: ['Yes, she does.', "No, she doesn't."],
    },
    {
      character: '👦 Bima',
      avatarEmoji: '👦',
      foodId: 'meatball' as FoodId,
      question: 'Does he like meatball?',
      clue: 'Bima loves meatball very much! 😋',
      correct: 'Yes, he does.',
      options: ['Yes, he does.', "No, he doesn't."],
    },
    {
      character: '👧 Maya',
      avatarEmoji: '👧',
      foodId: 'tofu' as FoodId,
      question: 'Does she like tofu?',
      clue: 'Maya is shaking her head gently. 🙅‍♀️',
      correct: "No, she doesn't.",
      options: ['Yes, she does.', "No, she doesn't."],
    },
  ];

  const handleP5Answer = (option: string) => {
    if (p5Selected !== null) return;
    setP5Selected(option);
    const curr = p5Questions[p5Index];
    if (option === curr.correct) {
      sound.playCorrect();
      sound.speak(curr.correct);
      confetti({ particleCount: 30, spread: 60 });
      setStarsEarned((s) => s + 1);
      onUpdateScore(20);
    } else {
      sound.playWrong();
    }
  };

  const nextP5 = () => {
    setP5Selected(null);
    setP5Index((prev) => (prev + 1) % p5Questions.length);
  };

  // --- BUILD YOUR SENTENCE (Sentence Builder) ---
  const builderPuzzles = [
    {
      targetSentence: 'She likes noodles.',
      scrambled: ['likes', 'She', 'noodles.'],
      foodId: 'noodles' as FoodId,
    },
    {
      targetSentence: 'I like rice.',
      scrambled: ['rice.', 'like', 'I'],
      foodId: 'rice' as FoodId,
    },
    {
      targetSentence: 'He likes meatball.',
      scrambled: ['meatball.', 'He', 'likes'],
      foodId: 'meatball' as FoodId,
    },
    {
      targetSentence: 'We like tofu.',
      scrambled: ['tofu.', 'We', 'like'],
      foodId: 'tofu' as FoodId,
    },
  ];

  const [builderIndex, setBuilderIndex] = useState<number>(0);
  const currentPuzzle = builderPuzzles[builderIndex];
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [availableWords, setAvailableWords] = useState<string[]>(currentPuzzle.scrambled);
  const [builderStatus, setBuilderStatus] = useState<'idle' | 'correct' | 'wrong'>('idle');

  const addWord = (word: string, indexInAvailable: number) => {
    sound.playClick();
    const nextSelected = [...selectedWords, word];
    const nextAvail = availableWords.filter((_, i) => i !== indexInAvailable);
    setSelectedWords(nextSelected);
    setAvailableWords(nextAvail);

    // If all words placed, check result
    if (nextSelected.length === currentPuzzle.scrambled.length) {
      const sentence = nextSelected.join(' ');
      if (sentence === currentPuzzle.targetSentence) {
        setBuilderStatus('correct');
        sound.playCorrect();
        sound.speak(`Great! ${sentence}`);
        confetti({ particleCount: 40, spread: 70 });
        setStarsEarned((s) => s + 2);
        onUpdateScore(30);
        onUnlockBadge('sentence_builder');
      } else {
        setBuilderStatus('wrong');
        sound.playWrong();
      }
    }
  };

  const removeWord = (word: string, indexInSelected: number) => {
    sound.playClick();
    setSelectedWords((prev) => prev.filter((_, i) => i !== indexInSelected));
    setAvailableWords((prev) => [...prev, word]);
    setBuilderStatus('idle');
  };

  const resetBuilder = () => {
    sound.playClick();
    setSelectedWords([]);
    setAvailableWords(currentPuzzle.scrambled);
    setBuilderStatus('idle');
  };

  const nextBuilder = () => {
    const nextIdx = (builderIndex + 1) % builderPuzzles.length;
    setBuilderIndex(nextIdx);
    setSelectedWords([]);
    setAvailableWords(builderPuzzles[nextIdx].scrambled);
    setBuilderStatus('idle');
  };

  return (
    <div className="py-6 sm:py-8 px-4 max-w-5xl mx-auto animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-violet-500 via-purple-500 to-sky-500 rounded-3xl p-6 sm:p-8 text-white shadow-xl mb-6 border-4 border-violet-300 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 bg-white/20 px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>PRACTICE ZONE • LATIHAN INTERAKTIF</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black font-bubble">
            PRACTICE ZONE
          </h1>
          <p className="text-violet-100 text-xs sm:text-sm font-semibold mt-1">
            Latih kosakata, kalimat, dan susun kata menjadi kalimat bahasa Inggris yang tepat!
          </p>
        </div>

        {/* Stars Counter */}
        <div className="flex items-center gap-3 bg-white/20 backdrop-blur-md px-5 py-3 rounded-2xl border-2 border-white/40">
          <Star className="w-8 h-8 text-amber-300 fill-amber-300 animate-bounce" />
          <div className="text-left">
            <span className="block text-[10px] font-extrabold uppercase text-violet-100">
              STARS EARNED
            </span>
            <span className="text-2xl font-black text-white font-bubble">
              {starsEarned} ⭐
            </span>
          </div>
        </div>
      </div>

      {/* Practice Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-6">
        {[
          { id: 'p1', label: '1. Choose Food' },
          { id: 'p2', label: '2. Like / Likes' },
          { id: 'p3', label: '3. Correct Sentence' },
          { id: 'p4', label: '4. Do you like?' },
          { id: 'p5', label: '5. Does she like?' },
          { id: 'builder', label: '🧩 Sentence Builder' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              sound.playClick();
              setActiveSection(tab.id as PracticeTab);
            }}
            className={`btn-bubble py-2.5 px-4 rounded-2xl text-xs sm:text-sm font-black border-2 transition-all ${
              activeSection === tab.id
                ? 'bg-violet-500 text-white border-violet-600 scale-105 shadow-md'
                : 'bg-white text-slate-700 border-slate-200 hover:border-violet-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main Practice Card */}
      <div className="bg-white rounded-3xl border-8 border-violet-200 shadow-xl p-6 sm:p-10 min-h-[460px] flex flex-col justify-between">
        {/* ================= PRACTICE 1: CHOOSE THE FOOD ================= */}
        {activeSection === 'p1' && (
          <div className="animate-fadeIn">
            <div className="text-center mb-6">
              <span className="text-xs font-black bg-sky-100 text-sky-800 px-3 py-1 rounded-full uppercase">
                PRACTICE 1 • QUESTION {p1Index + 1} OF {p1Questions.length}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-800 font-bubble mt-2">
                What food is this?
              </h2>
            </div>

            <div className="flex flex-col md:flex-row items-center justify-around gap-6 mb-6">
              {/* 3D Food */}
              <div className="flex flex-col items-center">
                <Food3DCanvas
                  foodId={p1Questions[p1Index].foodId}
                  size="lg"
                  showCardBanner={true}
                  onClick={() => sound.playFoodSound(p1Questions[p1Index].foodId)}
                />
                <span className="text-xs font-bold text-slate-400 mt-1">
                  Tap to hear sound!
                </span>
              </div>

              {/* Options */}
              <div className="grid grid-cols-2 gap-3 w-full max-w-sm">
                {p1Questions[p1Index].options.map((opt) => {
                  const isChosen = p1Selected === opt;
                  const isRight = opt === p1Questions[p1Index].correct;

                  let btnStyle = 'bg-white border-slate-200 text-slate-700 hover:border-sky-300';
                  if (p1Selected !== null) {
                    if (isRight) {
                      btnStyle = 'bg-emerald-500 text-white border-emerald-600 shadow-md';
                    } else if (isChosen) {
                      btnStyle = 'bg-rose-500 text-white border-rose-600';
                    }
                  }

                  return (
                    <button
                      key={opt}
                      onClick={() => handleP1Answer(opt)}
                      disabled={p1Selected !== null}
                      className={`btn-bubble py-4 px-4 rounded-2xl font-black text-base sm:text-lg border-3 transition-all ${btnStyle}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Feedback and Next */}
            {p1Selected !== null && (
              <div className="flex items-center justify-between bg-sky-50 rounded-2xl p-4 border-2 border-sky-200 animate-fadeIn">
                <div className="flex items-center gap-2">
                  {p1IsCorrect ? (
                    <span className="text-emerald-600 font-black text-base sm:text-lg flex items-center gap-1.5 font-bubble">
                      <CheckCircle2 className="w-6 h-6" />
                      🎉 Great! Correct! It is {p1Questions[p1Index].correct}!
                    </span>
                  ) : (
                    <span className="text-rose-500 font-bold text-sm flex items-center gap-1.5">
                      <XCircle className="w-5 h-5" />
                      Try again! The correct answer is {p1Questions[p1Index].correct}.
                    </span>
                  )}
                </div>

                <button
                  onClick={nextP1}
                  className="btn-bubble py-2.5 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-sm border-2 border-amber-500 flex items-center gap-1.5"
                >
                  <span>Pertanyaan Berikutnya</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ================= PRACTICE 2: COMPLETE THE SENTENCE ================= */}
        {activeSection === 'p2' && (
          <div className="animate-fadeIn">
            <div className="text-center mb-6">
              <span className="text-xs font-black bg-amber-100 text-amber-900 px-3 py-1 rounded-full uppercase">
                PRACTICE 2 • QUESTION {p2Index + 1} OF {p2Questions.length}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-800 font-bubble mt-2">
                Lengkapi kalimat berikut:
              </h2>
            </div>

            <div className="flex flex-col items-center justify-center gap-6 mb-8">
              <Food3DCanvas foodId={p2Questions[p2Index].food} size="md" />

              <div className="bg-sky-50 rounded-3xl py-4 px-8 border-4 border-sky-300 text-3xl sm:text-4xl font-black text-sky-950 font-bubble tracking-wide shadow-inner text-center">
                {p2Questions[p2Index].sentence.replace(
                  '___',
                  p2Answer ? p2Answer : '______'
                )}
              </div>

              {/* Options: LIKE or LIKES */}
              <div className="flex items-center gap-4">
                {['LIKE', 'LIKES'].map((opt) => {
                  const isRight = opt === p2Questions[p2Index].answer;
                  const isChosen = p2Answer === opt;
                  let style = 'bg-white border-slate-300 text-slate-800 hover:border-amber-400';
                  if (p2Answer !== null) {
                    if (isRight) style = 'bg-emerald-500 text-white border-emerald-600 shadow-md';
                    else if (isChosen) style = 'bg-rose-500 text-white border-rose-600';
                  }

                  return (
                    <button
                      key={opt}
                      onClick={() => handleP2Answer(opt)}
                      disabled={p2Answer !== null}
                      className={`btn-bubble py-4 px-10 rounded-2xl font-black text-xl border-4 ${style}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>

            {p2Answer !== null && (
              <div className="flex items-center justify-between bg-amber-50 rounded-2xl p-4 border-2 border-amber-200 animate-fadeIn">
                <span className="font-bold text-amber-950 text-sm">
                  {p2Answer === p2Questions[p2Index].answer
                    ? `⭐ Benar! Untuk subjek "${p2Questions[p2Index].subject}", gunakan ${p2Questions[p2Index].answer}!`
                    : `Yuk ingat lagi: subjek "${p2Questions[p2Index].subject}" menggunakan ${p2Questions[p2Index].answer}!`}
                </span>
                <button
                  onClick={nextP2}
                  className="btn-bubble py-2 px-5 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-sm border-2 border-amber-500 flex items-center gap-1.5"
                >
                  <span>Next</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ================= PRACTICE 3: CHOOSE THE CORRECT SENTENCE ================= */}
        {activeSection === 'p3' && (
          <div className="animate-fadeIn">
            <div className="text-center mb-6">
              <span className="text-xs font-black bg-emerald-100 text-emerald-900 px-3 py-1 rounded-full uppercase">
                PRACTICE 3 • QUESTION {p3Index + 1} OF {p3Questions.length}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-800 font-bubble mt-2">
                Pilih kalimat yang benar:
              </h2>
            </div>

            <div className="flex flex-col items-center justify-center gap-6 mb-6">
              <Food3DCanvas foodId={p3Questions[p3Index].foodId} size="md" />

              <div className="flex flex-col gap-3 w-full max-w-md">
                {p3Questions[p3Index].options.map((opt, idx) => {
                  const isRight = idx === p3Questions[p3Index].correctIndex;
                  const isChosen = p3Selected === idx;

                  let style = 'bg-white border-slate-200 text-slate-800 hover:border-emerald-300';
                  if (p3Selected !== null) {
                    if (isRight) style = 'bg-emerald-500 text-white border-emerald-600 shadow-md';
                    else if (isChosen) style = 'bg-rose-500 text-white border-rose-600';
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleP3Answer(idx)}
                      disabled={p3Selected !== null}
                      className={`btn-bubble py-4 px-6 rounded-2xl font-black text-lg text-left border-3 flex items-center justify-between ${style}`}
                    >
                      <span>{String.fromCharCode(65 + idx)}. {opt}</span>
                      {p3Selected !== null && isRight && <Check className="w-6 h-6" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {p3Selected !== null && (
              <div className="flex items-center justify-between bg-emerald-50 rounded-2xl p-4 border-2 border-emerald-200 animate-fadeIn">
                <span className="font-bold text-emerald-950 text-sm">
                  {p3Questions[p3Index].explanation}
                </span>
                <button
                  onClick={nextP3}
                  className="btn-bubble py-2 px-5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-black text-sm border-2 border-emerald-600 flex items-center gap-1.5"
                >
                  <span>Next</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ================= PRACTICE 4: DO YOU LIKE? ================= */}
        {activeSection === 'p4' && (
          <div className="animate-fadeIn">
            <div className="text-center mb-6">
              <span className="text-xs font-black bg-teal-100 text-teal-900 px-3 py-1 rounded-full uppercase">
                PRACTICE 4 • QUESTION {p4Index + 1} OF {p4Questions.length}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-800 font-bubble mt-2">
                {p4Questions[p4Index].question}
              </h2>
            </div>

            <div className="flex flex-col items-center justify-center gap-6 mb-8">
              <Food3DCanvas
                foodId={p4Questions[p4Index].foodId}
                size="lg"
                showCardBanner={true}
              />

              <div className="flex items-center gap-4">
                <button
                  onClick={() => handleP4Answer('yes')}
                  className={`btn-bubble py-4 px-8 rounded-2xl font-black text-xl border-3 ${
                    p4Answer === 'yes'
                      ? 'bg-emerald-500 text-white border-emerald-600 shadow-md'
                      : 'bg-white text-emerald-700 border-emerald-300 hover:bg-emerald-50'
                  }`}
                >
                  YES (Yes, I do.)
                </button>
                <button
                  onClick={() => handleP4Answer('no')}
                  className={`btn-bubble py-4 px-8 rounded-2xl font-black text-xl border-3 ${
                    p4Answer === 'no'
                      ? 'bg-rose-500 text-white border-rose-600 shadow-md'
                      : 'bg-white text-rose-700 border-rose-300 hover:bg-rose-50'
                  }`}
                >
                  NO (No, I don't.)
                </button>
              </div>
            </div>

            {p4Answer !== null && (
              <div className="flex items-center justify-between bg-teal-50 rounded-2xl p-4 border-2 border-teal-200 animate-fadeIn">
                <span className="font-bold text-teal-950 text-sm">
                  {p4Answer === 'yes'
                    ? `🎉 Great! You like ${p4Questions[p4Index].foodId}!`
                    : `👍 Understood! You answered: "No, I don't."`}
                </span>
                <button
                  onClick={nextP4}
                  className="btn-bubble py-2 px-5 rounded-xl bg-teal-500 hover:bg-teal-400 text-white font-black text-sm border-2 border-teal-600 flex items-center gap-1.5"
                >
                  <span>Next Food</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ================= PRACTICE 5: DOES SHE / HE LIKE? ================= */}
        {activeSection === 'p5' && (
          <div className="animate-fadeIn">
            <div className="text-center mb-6">
              <span className="text-xs font-black bg-rose-100 text-rose-900 px-3 py-1 rounded-full uppercase">
                PRACTICE 5 • QUESTION {p5Index + 1} OF {p5Questions.length}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-800 font-bubble mt-2">
                {p5Questions[p5Index].question}
              </h2>
              <p className="text-xs sm:text-sm font-bold text-slate-500 mt-1">
                Petunjuk: {p5Questions[p5Index].clue}
              </p>
            </div>

            <div className="flex flex-col md:flex-row items-center justify-around gap-6 mb-6">
              {/* Character & 3D Food */}
              <div className="flex items-center gap-4 bg-sky-50 rounded-3xl p-5 border-2 border-sky-200">
                <div className="text-5xl">{p5Questions[p5Index].avatarEmoji}</div>
                <div>
                  <span className="font-black text-slate-800 text-lg block">
                    {p5Questions[p5Index].character}
                  </span>
                  <Food3DCanvas foodId={p5Questions[p5Index].foodId} size="sm" />
                </div>
              </div>

              {/* Choices */}
              <div className="flex flex-col gap-3 w-full max-w-sm">
                {p5Questions[p5Index].options.map((opt) => {
                  const isRight = opt === p5Questions[p5Index].correct;
                  const isChosen = p5Selected === opt;

                  let style = 'bg-white border-slate-200 text-slate-800 hover:border-rose-300';
                  if (p5Selected !== null) {
                    if (isRight) style = 'bg-emerald-500 text-white border-emerald-600 shadow-md';
                    else if (isChosen) style = 'bg-rose-500 text-white border-rose-600';
                  }

                  return (
                    <button
                      key={opt}
                      onClick={() => handleP5Answer(opt)}
                      disabled={p5Selected !== null}
                      className={`btn-bubble py-4 px-6 rounded-2xl font-black text-lg border-3 ${style}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>

            {p5Selected !== null && (
              <div className="flex items-center justify-between bg-rose-50 rounded-2xl p-4 border-2 border-rose-200 animate-fadeIn">
                <span className="font-bold text-rose-950 text-sm">
                  {p5Selected === p5Questions[p5Index].correct
                    ? `⭐ Awesome! "${p5Questions[p5Index].correct}" is correct!`
                    : `Perhatikan petunjuk: jawaban yang tepat adalah "${p5Questions[p5Index].correct}"!`}
                </span>
                <button
                  onClick={nextP5}
                  className="btn-bubble py-2 px-5 rounded-xl bg-rose-500 hover:bg-rose-400 text-white font-black text-sm border-2 border-rose-600 flex items-center gap-1.5"
                >
                  <span>Next Question</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* ================= BUILD YOUR SENTENCE (Drag & Drop / Tap to Order) ================= */}
        {activeSection === 'builder' && (
          <div className="animate-fadeIn">
            <div className="text-center mb-6">
              <span className="text-xs font-black bg-violet-100 text-violet-900 px-3 py-1 rounded-full uppercase">
                SENTENCE BUILDER • PUZZLE {builderIndex + 1} OF {builderPuzzles.length}
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-800 font-bubble mt-2">
                Susun kata menjadi kalimat yang benar!
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-500 mt-1">
                Sentuh kata untuk memasukkannya ke garis kalimat di bawah.
              </p>
            </div>

            <div className="flex flex-col items-center justify-center gap-6 mb-6">
              {/* 3D Food */}
              <Food3DCanvas foodId={currentPuzzle.foodId} size="md" />

              {/* The Target Sentence Drop / Assembly Box */}
              <div className="w-full max-w-xl min-h-[70px] bg-slate-50 border-4 border-dashed border-violet-300 rounded-3xl p-3 flex flex-wrap items-center justify-center gap-2 shadow-inner">
                {selectedWords.length === 0 ? (
                  <span className="text-sm font-bold text-slate-400">
                    (Sentuh kata di bawah untuk menyusun kalimat)
                  </span>
                ) : (
                  selectedWords.map((word, idx) => (
                    <button
                      key={idx}
                      onClick={() => removeWord(word, idx)}
                      className="btn-bubble py-2.5 px-5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-base border-2 border-amber-500 shadow-md animate-pop"
                    >
                      {word} ✕
                    </button>
                  ))
                )}
              </div>

              {/* Available Words Pool */}
              <div className="flex flex-wrap items-center justify-center gap-3">
                {availableWords.map((word, idx) => (
                  <button
                    key={idx}
                    onClick={() => addWord(word, idx)}
                    className="btn-bubble py-3 px-6 rounded-2xl bg-white hover:bg-sky-50 text-sky-900 font-black text-lg border-3 border-sky-300 shadow-md"
                  >
                    {word}
                  </button>
                ))}
              </div>

              {/* Controls */}
              <div className="flex items-center gap-3">
                <button
                  onClick={resetBuilder}
                  className="btn-bubble flex items-center gap-1.5 py-2 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-300"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Susun Ulang</span>
                </button>
              </div>

              {/* Feedback */}
              {builderStatus === 'correct' && (
                <div className="bg-emerald-100 border-2 border-emerald-400 text-emerald-950 font-black text-base rounded-2xl py-3 px-6 animate-bounce-gentle flex items-center gap-2">
                  <span>🎉 Great! "{currentPuzzle.targetSentence}"</span>
                  <button
                    onClick={nextBuilder}
                    className="ml-3 btn-bubble py-1.5 px-4 rounded-xl bg-emerald-500 text-white text-xs font-bold"
                  >
                    Puzzle Berikutnya →
                  </button>
                </div>
              )}

              {builderStatus === 'wrong' && (
                <div className="bg-rose-100 border-2 border-rose-400 text-rose-950 font-bold text-sm rounded-2xl py-2 px-6 animate-shake">
                  ❌ Try again! Urutkan: Subjek + Like/Likes + Makanan.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Bottom CTA: Go to Game Arena */}
        <div className="border-t-2 border-slate-100 pt-6 mt-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-500">
            <Award className="w-5 h-5 text-violet-500" />
            <span>Selesaikan latihan untuk membuka Game Arena!</span>
          </div>

          <button
            onClick={() => {
              sound.playVictory();
              onCompletePractice();
            }}
            className="btn-bubble flex items-center gap-2 py-3 px-7 rounded-2xl bg-gradient-to-r from-orange-400 to-amber-500 hover:from-orange-500 hover:to-amber-600 text-amber-950 font-black text-base border-2 border-orange-400 shadow-lg shadow-orange-200"
          >
            <span>Lanjut ke Game Arena</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
