import React, { useState } from 'react';
import { Volume2, VolumeX, Music, RotateCcw, AlertTriangle, Sparkles } from 'lucide-react';
import { sound } from '../utils/audio';

interface HeaderProps {
  onReset: () => void;
  isMusicOn: boolean;
  isSoundOn: boolean;
  onToggleMusic: () => void;
  onToggleSound: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onReset,
  isMusicOn,
  isSoundOn,
  onToggleMusic,
  onToggleSound,
}) => {
  const [showResetModal, setShowResetModal] = useState(false);

  const confirmReset = () => {
    sound.playClick();
    onReset();
    setShowResetModal(false);
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-4 border-amber-300 shadow-sm px-4 lg:px-8 py-3 transition-all">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Left / Center Identity */}
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 border-2 border-amber-500 flex items-center justify-center shadow-md shadow-amber-200 shrink-0 transform -rotate-3 hover:rotate-0 transition-transform">
              <span className="text-2xl">🍜</span>
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-amber-950 font-bubble">
                  WHAT FOOD DO YOU LIKE?
                </h1>
                <span className="bg-sky-500 text-white text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  KIDS
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-600 justify-center sm:justify-start">
                <span className="text-amber-600 font-bold">ENGLISH FOR KIDS</span>
                <span className="text-slate-300">•</span>
                <span className="text-slate-500">Food • Likes • Simple Questions</span>
              </div>
            </div>
          </div>

          {/* Right Controls: Reset, Music, Sound */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Reset Button */}
            <button
              onClick={() => {
                sound.playClick();
                setShowResetModal(true);
              }}
              className="btn-bubble flex items-center gap-1.5 px-3 py-2 rounded-2xl bg-rose-100 hover:bg-rose-200 text-rose-700 text-xs sm:text-sm font-bold border-2 border-rose-300 transition-colors"
              title="Reset learning & game progress"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset</span>
            </button>

            {/* Music Toggle */}
            <button
              onClick={() => {
                sound.playClick();
                onToggleMusic();
              }}
              className={`btn-bubble flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs sm:text-sm font-bold border-2 transition-all ${
                isMusicOn
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-400 hover:bg-emerald-200'
                  : 'bg-slate-100 text-slate-400 border-slate-300 hover:bg-slate-200'
              }`}
              title={isMusicOn ? 'Turn Background Music OFF' : 'Turn Background Music ON'}
            >
              <Music className={`w-4 h-4 ${isMusicOn ? 'animate-bounce-gentle' : ''}`} />
              <span className="hidden md:inline">Music</span>
              <span className="text-[11px] uppercase font-extrabold">
                {isMusicOn ? 'ON' : 'OFF'}
              </span>
            </button>

            {/* Sound Effects & Voice Toggle */}
            <button
              onClick={() => {
                onToggleSound();
              }}
              className={`btn-bubble flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs sm:text-sm font-bold border-2 transition-all ${
                isSoundOn
                  ? 'bg-amber-100 text-amber-900 border-amber-400 hover:bg-amber-200'
                  : 'bg-slate-100 text-slate-400 border-slate-300 hover:bg-slate-200'
              }`}
              title={isSoundOn ? 'Turn Sound & Voice OFF' : 'Turn Sound & Voice ON'}
            >
              {isSoundOn ? (
                <Volume2 className="w-4 h-4 text-amber-700" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-400" />
              )}
              <span className="hidden md:inline">Sound</span>
              <span className="text-[11px] uppercase font-extrabold">
                {isSoundOn ? 'ON' : 'OFF'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Confirmation Modal for Reset */}
      {showResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full border-4 border-amber-300 shadow-2xl text-center">
            <div className="w-16 h-16 bg-amber-100 border-2 border-amber-400 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-600">
              <AlertTriangle className="w-8 h-8" />
            </div>

            <h3 className="text-2xl font-extrabold text-slate-900 mb-2 font-bubble">
              Reset all progress?
            </h3>
            <p className="text-sm font-medium text-slate-600 mb-6 leading-relaxed">
              This will reset your learning progress, completed exercises, scores, player names, and game badges. Are you sure?
            </p>

            <div className="flex items-center justify-center gap-4">
              <button
                onClick={() => {
                  sound.playClick();
                  setShowResetModal(false);
                }}
                className="btn-bubble flex-1 py-3 px-5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold border-2 border-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={confirmReset}
                className="btn-bubble flex-1 py-3 px-5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-bold border-2 border-rose-600 shadow-md shadow-rose-200"
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
