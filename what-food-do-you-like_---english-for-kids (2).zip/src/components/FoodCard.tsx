import React, { useState } from 'react';
import { FoodItem } from '../types';
import { Food3DCanvas } from './Food3DCanvas';
import { Volume2, Sparkles } from 'lucide-react';
import { sound } from '../utils/audio';

interface FoodCardProps {
  food: FoodItem;
  size?: 'sm' | 'md' | 'lg';
  showSentence?: boolean;
  onSelect?: (food: FoodItem) => void;
  isSelected?: boolean;
}

export const FoodCard: React.FC<FoodCardProps> = ({
  food,
  size = 'md',
  showSentence = true,
  onSelect,
  isSelected = false,
}) => {
  const [justTapped, setJustTapped] = useState(false);

  const handleCardClick = () => {
    setJustTapped(true);
    sound.playFoodSound(food.name);
    setTimeout(() => setJustTapped(false), 2000);
    if (onSelect) {
      onSelect(food);
    }
  };

  const handleSpeak = (e: React.MouseEvent) => {
    e.stopPropagation();
    sound.speak(`${food.name}. ${food.exampleSentence}`);
  };

  return (
    <div
      onClick={handleCardClick}
      className={`relative flex flex-col items-center bg-white rounded-3xl p-4 transition-all duration-200 cursor-pointer border-4 ${
        isSelected
          ? 'border-amber-400 ring-4 ring-amber-200 scale-105 shadow-xl'
          : 'border-slate-100 hover:border-sky-300 shadow-md hover:shadow-xl hover:-translate-y-1'
      }`}
    >
      {/* 3D Food Canvas */}
      <div className="relative">
        <Food3DCanvas
          foodId={food.id}
          size={size}
          interactive={true}
          onClick={() => {
            setJustTapped(true);
            setTimeout(() => setJustTapped(false), 2000);
            if (onSelect) onSelect(food);
          }}
        />

        {/* Floating Tap Me Badge */}
        <div className="absolute top-1 right-1 bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm animate-bounce-gentle">
          <Sparkles className="w-3 h-3 text-amber-600" />
          <span>Tap 3D!</span>
        </div>
      </div>

      {/* Name and Pronunciation */}
      <div className="w-full flex items-center justify-between mt-2 pt-2 border-t border-slate-100">
        <div>
          <div className="text-xl font-bold tracking-wide text-slate-800 uppercase">
            {food.name}
          </div>
          <div className="text-xs font-medium text-slate-400">
            ({food.indonesianName})
          </div>
        </div>

        <button
          onClick={handleSpeak}
          aria-label={`Listen to ${food.name}`}
          className="w-10 h-10 rounded-2xl bg-sky-100 hover:bg-sky-200 text-sky-700 flex items-center justify-center transition-transform active:scale-90 shadow-sm"
        >
          <Volume2 className="w-5 h-5" />
        </button>
      </div>

      {/* Sentence */}
      {showSentence && (
        <div className="w-full mt-2 bg-sky-50 rounded-2xl py-2 px-3 text-center border border-sky-100">
          <span className="text-sm font-bold text-sky-800">
            "{food.exampleSentence}"
          </span>
        </div>
      )}

      {/* Interactive feedback indicator */}
      {justTapped && (
        <div className="absolute -bottom-3 bg-amber-400 text-amber-950 font-bold text-xs px-3 py-1 rounded-full shadow-md animate-pop">
          {food.name} • {food.exampleSentence}
        </div>
      )}
    </div>
  );
};
