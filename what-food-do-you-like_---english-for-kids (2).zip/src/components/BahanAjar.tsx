import React, { useState } from 'react';
import { FoodId } from '../types';
import { FOOD_ITEMS } from '../data/foodData';
import { Food3DCanvas } from './Food3DCanvas';
import { sound } from '../utils/audio';
import {
  ChevronLeft,
  ChevronRight,
  Volume2,
  Sparkles,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  BookOpen
} from 'lucide-react';

interface BahanAjarProps {
  onCompleteBook: () => void;
  onUpdateProgress: (type: 'vocabulary' | 'grammar', percent: number) => void;
}

export const BahanAjar: React.FC<BahanAjarProps> = ({ onCompleteBook, onUpdateProgress }) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const totalPages = 7;

  // Chapter 1 state
  const [activeFoodBab1, setActiveFoodBab1] = useState<FoodId>('rice');

  // Chapter 2 state
  const [selectedFoodBab2, setSelectedFoodBab2] = useState<FoodId>('noodles');
  const [bab2QuestionMode, setBab2QuestionMode] = useState<'what_food' | 'favorite' | 'do_you_like'>('what_food');
  const [bab2DoChoice, setBab2DoChoice] = useState<'yes' | 'no'>('yes');

  // Chapter 3 state
  const [favoriteFoodBab3, setFavoriteFoodBab3] = useState<FoodId>('meatball');

  // Chapter 4 state (Like or Likes quiz check)
  const [bab4Answer, setBab4Answer] = useState<string | null>(null);

  // Chapter 5 state (Do you like)
  const [bab5Choice, setBab5Choice] = useState<'yes' | 'no' | null>(null);
  const [bab5Food, setBab5Food] = useState<FoodId>('noodles');

  // Chapter 6 state (Does she like)
  const [bab6Answer, setBab6Answer] = useState<'correct' | 'wrong' | null>(null);

  const goToPage = (page: number) => {
    sound.playClick();
    setCurrentPage(page);
    // Update learning progress
    if (page >= 3) onUpdateProgress('vocabulary', Math.min(100, page * 16));
    if (page >= 5) onUpdateProgress('grammar', Math.min(100, (page - 2) * 20));
  };

  return (
    <div className="py-6 sm:py-8 px-4 max-w-5xl mx-auto animate-fadeIn">
      {/* Textbook Header */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-2 bg-sky-100 text-sky-800 font-extrabold px-4 py-1.5 rounded-full text-xs sm:text-sm border border-sky-300 uppercase tracking-wider mb-2">
          <BookOpen className="w-4 h-4 text-sky-600" />
          <span>BUKU BELAJAR SISWA • DIGITAL TEXTBOOK</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-amber-950 font-bubble">
          WHAT FOOD DO YOU LIKE?
        </h1>
        <p className="text-xs sm:text-sm font-bold text-slate-500 mt-1">
          Halaman {currentPage} dari {totalPages}
        </p>
      </div>

      {/* Book Container with 3D Page Aesthetic */}
      <div className="relative bg-white rounded-[2rem] border-8 border-sky-300 shadow-2xl p-6 sm:p-10 min-h-[580px] flex flex-col justify-between">
        {/* Top Pagination Bar */}
        <div className="flex items-center justify-between border-b-2 border-slate-100 pb-4 mb-6">
          <div className="flex items-center gap-2">
            <span className="text-2xl">📖</span>
            <span className="text-lg sm:text-xl font-black text-slate-800 font-bubble">
              Halaman {currentPage}
            </span>
          </div>

          {/* Quick Page Dots */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => goToPage(idx + 1)}
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full text-xs font-black transition-all ${
                  currentPage === idx + 1
                    ? 'bg-amber-400 text-amber-950 scale-110 shadow-sm border-2 border-amber-500'
                    : 'bg-slate-100 text-slate-500 hover:bg-sky-100'
                }`}
              >
                {idx + 1}
              </button>
            ))}
          </div>
        </div>

        {/* ---------------- PAGE 1: BAB 1 - KNOW THE FOOD ---------------- */}
        {currentPage === 1 && (
          <div className="animate-fadeIn flex-1">
            <div className="text-center mb-6">
              <span className="bg-amber-100 text-amber-900 text-xs font-black px-3 py-1 rounded-full uppercase">
                BAB 1
              </span>
              <h2 className="text-2xl sm:text-4xl font-black text-slate-900 font-bubble mt-1">
                KNOW THE FOOD
              </h2>
              <div className="flex items-center justify-center gap-2 mt-2 text-xs sm:text-sm font-bold text-sky-700 bg-sky-50 py-1.5 px-4 rounded-full max-w-md mx-auto border border-sky-200">
                <span>LOOK</span> ➔ <span>TAP 3D</span> ➔ <span>LISTEN</span> ➔ <span>SAY</span>
              </div>
            </div>

            {/* Food Selector Tabs */}
            <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-6">
              {FOOD_ITEMS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    sound.playClick();
                    setActiveFoodBab1(item.id);
                  }}
                  className={`btn-bubble px-4 py-2 rounded-2xl font-bold text-sm border-2 transition-all ${
                    activeFoodBab1 === item.id
                      ? 'bg-amber-400 text-amber-950 border-amber-500 scale-105 shadow-md'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-amber-300'
                  }`}
                >
                  {item.name}
                </button>
              ))}
            </div>

            {/* Main Interactive Stage for Selected Food */}
            {(() => {
              const currentItem = FOOD_ITEMS.find((f) => f.id === activeFoodBab1)!;
              return (
                <div className="bg-gradient-to-b from-sky-50 to-amber-50 rounded-3xl p-6 border-4 border-sky-200 flex flex-col md:flex-row items-center justify-around gap-6">
                  {/* Large 3D Interactive Model */}
                  <div className="flex flex-col items-center">
                    <Food3DCanvas
                      foodId={currentItem.id}
                      size="lg"
                      showCardBanner={true}
                      onClick={() => sound.playFoodSound(currentItem.name)}
                    />
                    <span className="text-xs font-bold text-slate-400 mt-1">
                      👆 Tap or drag to rotate 3D food!
                    </span>
                  </div>

                  {/* Word, Meaning, Pronunciation & Sentence */}
                  <div className="flex flex-col items-center md:items-start text-center md:text-left max-w-sm">
                    <div className="text-4xl sm:text-5xl font-black text-slate-900 tracking-wider font-bubble uppercase">
                      {currentItem.name}
                    </div>
                    <div className="text-lg font-bold text-amber-700 mb-3">
                      ({currentItem.indonesianName})
                    </div>
                    <p className="text-xs sm:text-sm font-medium text-slate-600 mb-4 leading-relaxed">
                      {currentItem.description}
                    </p>

                    <div className="flex items-center gap-3 mb-4">
                      <button
                        onClick={() => sound.playFoodSound(currentItem.name)}
                        className="btn-bubble flex items-center gap-2 py-3 px-5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-sm shadow-md border-2 border-amber-500"
                      >
                        <Volume2 className="w-5 h-5 text-amber-900" />
                        <span>"Listen: {currentItem.name}"</span>
                      </button>

                      <button
                        onClick={() => sound.speak(currentItem.name)}
                        className="btn-bubble py-3 px-4 rounded-2xl bg-sky-500 hover:bg-sky-400 text-white font-bold text-sm shadow-md border-2 border-sky-600"
                        title="Pronunciation only"
                      >
                        🔊 Word
                      </button>
                    </div>

                    <div className="w-full bg-white rounded-2xl p-3 border-2 border-amber-200">
                      <span className="text-xs font-bold text-slate-400 block uppercase">
                        Contoh Kalimat:
                      </span>
                      <span className="text-base font-black text-sky-800">
                        "{currentItem.exampleSentence}"
                      </span>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* ---------------- PAGE 2: MEET THE FOOD! COLLECTION ---------------- */}
        {currentPage === 2 && (
          <div className="animate-fadeIn flex-1">
            <div className="text-center mb-6">
              <span className="bg-sky-100 text-sky-900 text-xs font-black px-3 py-1 rounded-full uppercase">
                FOOD COLLECTION
              </span>
              <h2 className="text-2xl sm:text-4xl font-black text-slate-900 font-bubble mt-1">
                MEET THE FOOD!
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-1 max-w-lg mx-auto">
                Sentuh setiap makanan 3D untuk melihat gerakannya, mendengarkan pengucapannya, serta melihat kalimatnya!
              </p>
              <div className="mt-2 inline-flex items-center gap-2 text-xs font-bold text-amber-800 bg-amber-100 px-3 py-1 rounded-full">
                <span>3D FOOD ➔ SOUND ➔ WORD ➔ SENTENCE</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {FOOD_ITEMS.map((item) => (
                <div
                  key={item.id}
                  onClick={() => sound.playFoodSound(item.name)}
                  className="bg-white rounded-3xl p-4 border-4 border-sky-100 hover:border-amber-400 shadow-md hover:shadow-xl transition-all cursor-pointer flex flex-col items-center text-center group"
                >
                  <Food3DCanvas
                    foodId={item.id}
                    size="sm"
                    showCardBanner={true}
                    onClick={() => sound.playFoodSound(item.name)}
                  />
                  <span className="text-lg font-black text-slate-800 uppercase mt-1">
                    {item.name}
                  </span>
                  <span className="text-xs font-bold text-slate-400">
                    ({item.indonesianName})
                  </span>

                  <div className="mt-3 w-full bg-sky-50 group-hover:bg-amber-50 rounded-xl py-2 px-1 border border-sky-100 group-hover:border-amber-200 transition-colors">
                    <span className="text-xs font-bold text-sky-800 group-hover:text-amber-900">
                      "{item.exampleSentence}"
                    </span>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      sound.speak(item.exampleSentence);
                    }}
                    className="mt-2 text-xs font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Dengar</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ---------------- PAGE 3: BAB 2 - PILIHAN PERTANYAAN & POLA JAWABAN ---------------- */}
        {currentPage === 3 && (
          <div className="animate-fadeIn flex-1">
            <div className="text-center mb-5">
              <span className="bg-emerald-100 text-emerald-900 text-xs font-black px-3 py-1 rounded-full uppercase">
                BAB 2 • PILIHAN PERTANYAAN & POLA JAWABAN
              </span>
              <h2 className="text-2xl sm:text-4xl font-black text-slate-900 font-bubble mt-1">
                PILIHAN TANYA & JAWAB
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-1">
                Pilih jenis pertanyaan di bawah untuk melihat pola jawaban bahasa Inggris yang tepat!
              </p>
            </div>

            {/* 3 PILIHAN PERTANYAAN (TABS) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 max-w-2xl mx-auto mb-6">
              {/* Pilihan 1: What is your favorite food? */}
              <button
                onClick={() => {
                  sound.playClick();
                  setBab2QuestionMode('favorite');
                  sound.speak("What is your favorite food?");
                }}
                className={`btn-bubble p-3 rounded-2xl border-2 text-left transition-all ${
                  bab2QuestionMode === 'favorite'
                    ? 'bg-violet-500 text-white border-violet-600 shadow-md ring-2 ring-violet-200 scale-102'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-violet-300'
                }`}
              >
                <div className="text-[10px] font-black uppercase opacity-80">PILIHAN 1</div>
                <div className="text-sm font-black font-bubble leading-snug">"What is your favorite food?"</div>
                <div className="text-[11px] font-bold mt-1 opacity-90">➔ Jawab: My favorite food is...</div>
              </button>

              {/* Pilihan 2: What food do you like? */}
              <button
                onClick={() => {
                  sound.playClick();
                  setBab2QuestionMode('what_food');
                  sound.speak("What food do you like?");
                }}
                className={`btn-bubble p-3 rounded-2xl border-2 text-left transition-all ${
                  bab2QuestionMode === 'what_food'
                    ? 'bg-emerald-500 text-white border-emerald-600 shadow-md ring-2 ring-emerald-200 scale-102'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-300'
                }`}
              >
                <div className="text-[10px] font-black uppercase opacity-80">PILIHAN 2</div>
                <div className="text-sm font-black font-bubble leading-snug">"What food do you like?"</div>
                <div className="text-[11px] font-bold mt-1 opacity-90">➔ Jawab: I like...</div>
              </button>

              {/* Pilihan 3: Do you like ...? */}
              <button
                onClick={() => {
                  sound.playClick();
                  setBab2QuestionMode('do_you_like');
                  sound.speak(`Do you like ${selectedFoodBab2}?`);
                }}
                className={`btn-bubble p-3 rounded-2xl border-2 text-left transition-all ${
                  bab2QuestionMode === 'do_you_like'
                    ? 'bg-amber-400 text-amber-950 border-amber-500 shadow-md ring-2 ring-amber-200 scale-102'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-amber-300'
                }`}
              >
                <div className="text-[10px] font-black uppercase opacity-80">PILIHAN 3</div>
                <div className="text-sm font-black font-bubble leading-snug">"Do you like ...?"</div>
                <div className="text-[11px] font-bold mt-1 opacity-90">➔ Jawab: Yes, I do. I like...</div>
              </button>
            </div>

            {/* Dynamic Question Audio Box */}
            <div
              className={`rounded-2xl p-4 border-2 flex items-center justify-between max-w-xl mx-auto mb-6 transition-colors ${
                bab2QuestionMode === 'favorite'
                  ? 'bg-violet-50 border-violet-300'
                  : bab2QuestionMode === 'what_food'
                  ? 'bg-emerald-50 border-emerald-300'
                  : 'bg-amber-50 border-amber-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="text-3xl">🗣️</span>
                <div>
                  <div className="text-base sm:text-lg font-black text-slate-900 font-bubble">
                    {bab2QuestionMode === 'favorite' && '"What is your favorite food?"'}
                    {bab2QuestionMode === 'what_food' && '"What food do you like?"'}
                    {bab2QuestionMode === 'do_you_like' && `"Do you like ${selectedFoodBab2}?"`}
                  </div>
                  <div className="text-xs font-semibold text-slate-600">
                    {bab2QuestionMode === 'favorite' && '(Apa makanan kesukaanmu?)'}
                    {bab2QuestionMode === 'what_food' && '(Makanan apa yang kamu sukai?)'}
                    {bab2QuestionMode === 'do_you_like' && `(Apakah kamu suka ${selectedFoodBab2}?)`}
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  if (bab2QuestionMode === 'favorite') sound.speak("What is your favorite food?");
                  else if (bab2QuestionMode === 'what_food') sound.speak("What food do you like?");
                  else sound.speak(`Do you like ${selectedFoodBab2}?`);
                }}
                className="btn-bubble py-2 px-3 rounded-xl bg-white hover:bg-slate-50 text-slate-900 font-bold text-xs flex items-center gap-1.5 border border-slate-300 shadow-xs"
              >
                <Volume2 className="w-4 h-4 text-sky-600" />
                <span>Audio</span>
              </button>
            </div>

            {/* Interactive Food Picker & Matching Sentence Output */}
            <div className="bg-slate-50 rounded-3xl p-6 border-4 border-slate-200 text-center">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                Pilih makanan untuk mengubah kalimat jawaban secara langsung:
              </div>

              {/* Food Pickers */}
              <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-6">
                {FOOD_ITEMS.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      sound.playClick();
                      setSelectedFoodBab2(item.id);
                      sound.playFoodSound(item.name);
                    }}
                    className={`btn-bubble px-4 py-2.5 rounded-2xl font-black text-sm border-2 transition-all ${
                      selectedFoodBab2 === item.id
                        ? 'bg-amber-400 text-amber-950 border-amber-500 scale-105 shadow-md'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-amber-300'
                    }`}
                  >
                    {item.name}
                  </button>
                ))}
              </div>

              {/* In "Do you like...?" mode, provide YES / NO choice */}
              {bab2QuestionMode === 'do_you_like' && (
                <div className="flex flex-wrap items-center justify-center gap-3 mb-5">
                  <span className="text-xs font-bold text-slate-500 uppercase">Jawaban:</span>
                  <button
                    onClick={() => {
                      sound.playClick();
                      setBab2DoChoice('yes');
                      sound.speak(`Yes, I do. I like ${selectedFoodBab2}.`);
                    }}
                    className={`btn-bubble py-2 px-4 rounded-xl text-xs font-black border-2 ${
                      bab2DoChoice === 'yes'
                        ? 'bg-emerald-500 text-white border-emerald-600 shadow-sm'
                        : 'bg-white text-emerald-700 border-emerald-300'
                    }`}
                  >
                    YES (Yes, I do. I like {selectedFoodBab2}.)
                  </button>
                  <button
                    onClick={() => {
                      sound.playClick();
                      setBab2DoChoice('no');
                      sound.speak("No, I don't.");
                    }}
                    className={`btn-bubble py-2 px-4 rounded-xl text-xs font-black border-2 ${
                      bab2DoChoice === 'no'
                        ? 'bg-rose-500 text-white border-rose-600 shadow-sm'
                        : 'bg-white text-rose-700 border-rose-300'
                    }`}
                  >
                    NO (No, I don't.)
                  </button>
                </div>
              )}

              {/* Display Result Food & Matching Answer */}
              <div className="flex flex-col items-center">
                <Food3DCanvas
                  foodId={selectedFoodBab2}
                  size="md"
                  showCardBanner={false}
                  onClick={() => sound.playFoodSound(selectedFoodBab2)}
                />

                {/* THE RESULTING SENTENCE (MATCHING ANSWER FORMAT) */}
                <div className="mt-3 bg-white rounded-3xl py-4 px-6 sm:px-8 border-4 border-amber-300 shadow-md flex items-center justify-between gap-4 max-w-lg w-full">
                  <div className="text-left flex-1">
                    <span className="text-[10px] font-black uppercase text-amber-600 block">
                      POLA JAWABAN YANG TEPAT:
                    </span>
                    <span className="text-lg sm:text-2xl font-black text-amber-950 font-bubble leading-snug">
                      {bab2QuestionMode === 'favorite' && `My favorite food is ${selectedFoodBab2}.`}
                      {bab2QuestionMode === 'what_food' && `I like ${selectedFoodBab2}.`}
                      {bab2QuestionMode === 'do_you_like' && (
                        bab2DoChoice === 'yes'
                          ? `Yes, I do. I like ${selectedFoodBab2}.`
                          : `No, I don't.`
                      )}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      const text =
                        bab2QuestionMode === 'favorite'
                          ? `My favorite food is ${selectedFoodBab2}.`
                          : bab2QuestionMode === 'what_food'
                          ? `I like ${selectedFoodBab2}.`
                          : bab2DoChoice === 'yes'
                          ? `Yes, I do. I like ${selectedFoodBab2}.`
                          : `No, I don't.`;
                      sound.speak(text);
                    }}
                    className="w-12 h-12 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-900 flex items-center justify-center shrink-0 shadow-xs"
                    title="Dengarkan kalimat jawaban"
                  >
                    <Volume2 className="w-6 h-6" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ---------------- PAGE 4: BAB 3 - FAVORITE FOOD ---------------- */}
        {currentPage === 4 && (
          <div className="animate-fadeIn flex-1">
            <div className="text-center mb-6">
              <span className="bg-violet-100 text-violet-900 text-xs font-black px-3 py-1 rounded-full uppercase">
                BAB 3
              </span>
              <h2 className="text-2xl sm:text-4xl font-black text-slate-900 font-bubble mt-1">
                WHAT'S YOUR FAVORITE FOOD?
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-1">
                Gunakan pola: <strong>"My favorite food is [food]."</strong>
              </p>
            </div>

            {/* Question Banner */}
            <div className="bg-violet-50 rounded-2xl p-4 border-2 border-violet-200 flex items-center justify-between max-w-xl mx-auto mb-6">
              <div className="flex items-center gap-3">
                <span className="text-3xl">🌟</span>
                <div>
                  <div className="text-base sm:text-lg font-black text-violet-950 font-bubble">
                    "What's your favorite food?"
                  </div>
                  <div className="text-xs font-semibold text-violet-700">
                    (Apa makanan kesukaanmu?)
                  </div>
                </div>
              </div>
              <button
                onClick={() => sound.speak("What's your favorite food?")}
                className="btn-bubble py-2 px-3 rounded-xl bg-violet-400 hover:bg-violet-300 text-violet-950 font-bold text-xs flex items-center gap-1.5"
              >
                <Volume2 className="w-4 h-4" />
                <span>Audio</span>
              </button>
            </div>

            {/* Interactive Favorite Food Chooser */}
            <div className="bg-sky-50 rounded-3xl p-6 border-4 border-sky-200 text-center">
              <div className="text-xs font-bold text-sky-800 uppercase tracking-wider mb-2">
                Pilih makanan kesukaanmu:
              </div>

              <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-6">
                {FOOD_ITEMS.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      sound.playClick();
                      setFavoriteFoodBab3(item.id);
                      sound.playFoodSound(item.name);
                    }}
                    className={`btn-bubble px-4 py-2.5 rounded-2xl font-black text-sm border-2 transition-all ${
                      favoriteFoodBab3 === item.id
                        ? 'bg-violet-400 text-violet-950 border-violet-500 scale-105 shadow-md'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-violet-300'
                    }`}
                  >
                    ⭐ {item.name}
                  </button>
                ))}
              </div>

              <div className="flex flex-col items-center">
                <Food3DCanvas
                  foodId={favoriteFoodBab3}
                  size="md"
                  showCardBanner={true}
                  onClick={() => sound.playFoodSound(favoriteFoodBab3)}
                />

                <div className="mt-3 bg-white rounded-2xl py-3 px-6 border-4 border-violet-300 shadow-md flex items-center gap-3">
                  <span className="text-xl sm:text-2xl font-black text-violet-950 font-bubble">
                    My favorite food is {favoriteFoodBab3}.
                  </span>
                  <button
                    onClick={() => sound.speak(`My favorite food is ${favoriteFoodBab3}.`)}
                    className="w-10 h-10 rounded-full bg-violet-100 hover:bg-violet-200 text-violet-900 flex items-center justify-center"
                  >
                    <Volume2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Rangkuman Pola Tanya & Jawab */}
              <div className="mt-6 bg-white/90 rounded-2xl p-4 border-2 border-violet-200 text-left max-w-xl mx-auto">
                <span className="text-xs font-black uppercase text-violet-700 block mb-2">
                  📌 Rangkuman Pola Tanya & Jawab:
                </span>
                <ul className="space-y-1.5 text-xs sm:text-sm font-bold text-slate-700">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-violet-500"></span>
                    <span><strong>"What is your favorite food?"</strong> ➔ <em>"My favorite food is [food]."</em></span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span><strong>"What food do you like?"</strong> ➔ <em>"I like [food]."</em></span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    <span><strong>"Do you like [food]?"</strong> ➔ <em>"Yes, I do. I like [food]." / "No, I don't."</em></span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* ---------------- PAGE 5: BAB 4 - LIKE OR LIKES? ---------------- */}
        {currentPage === 5 && (
          <div className="animate-fadeIn flex-1">
            <div className="text-center mb-6">
              <span className="bg-orange-100 text-orange-900 text-xs font-black px-3 py-1 rounded-full uppercase">
                BAB 4 • TATA BAHASA
              </span>
              <h2 className="text-2xl sm:text-4xl font-black text-slate-900 font-bubble mt-1">
                LIKE OR LIKES?
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-1">
                Kapan kita menggunakan <strong>LIKE</strong> dan kapan <strong>LIKES</strong>?
              </p>
            </div>

            {/* Grammar Formula Comparison Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 mb-6">
              {/* Group 1: I / You / We / They + LIKE */}
              <div className="bg-sky-50 rounded-3xl p-5 border-4 border-sky-300">
                <div className="flex items-center justify-between mb-3">
                  <span className="bg-sky-500 text-white font-black text-xs px-3 py-1 rounded-full">
                    TANPA -S
                  </span>
                  <span className="text-2xl font-black text-sky-800 font-bubble">LIKE</span>
                </div>
                <div className="text-sm font-bold text-sky-900 mb-3">
                  I / You / We / They ➔ <span className="underline decoration-sky-400">LIKE</span>
                </div>
                <ul className="space-y-1.5 text-xs sm:text-sm font-semibold text-slate-700">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-sky-400"></span>
                    <span><strong>I like</strong> rice.</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-sky-400"></span>
                    <span><strong>You like</strong> noodles.</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-sky-400"></span>
                    <span><strong>We like</strong> tofu.</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-sky-400"></span>
                    <span><strong>They like</strong> omelet.</span>
                  </li>
                </ul>
              </div>

              {/* Group 2: He / She + LIKES */}
              <div className="bg-amber-50 rounded-3xl p-5 border-4 border-amber-300">
                <div className="flex items-center justify-between mb-3">
                  <span className="bg-amber-500 text-white font-black text-xs px-3 py-1 rounded-full">
                    TAMBAH -S
                  </span>
                  <span className="text-2xl font-black text-amber-800 font-bubble">LIKES</span>
                </div>
                <div className="text-sm font-bold text-amber-900 mb-3">
                  He / She ➔ <span className="underline decoration-amber-400">LIKES</span>
                </div>
                <ul className="space-y-1.5 text-xs sm:text-sm font-semibold text-slate-700">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    <span><strong>He likes</strong> rice.</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    <span><strong>She likes</strong> noodles.</span>
                  </li>
                </ul>

                <div className="mt-4 pt-3 border-t border-amber-200 text-xs">
                  <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Benar: She likes noodles.</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-rose-600 font-bold mt-1">
                    <XCircle className="w-4 h-4 shrink-0" />
                    <span>Salah: She like noodles.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Interactive Mini-Quiz */}
            <div className="bg-white rounded-2xl p-4 border-2 border-slate-200 text-center">
              <span className="text-xs font-bold text-slate-500 block mb-2 uppercase">
                Mini Cek: Manakah kalimat yang tepat?
              </span>
              <div className="flex flex-wrap justify-center gap-3">
                <button
                  onClick={() => {
                    setBab4Answer('wrong');
                    sound.playWrong();
                  }}
                  className={`btn-bubble py-2.5 px-5 rounded-2xl font-bold text-sm border-2 ${
                    bab4Answer === 'wrong'
                      ? 'bg-rose-100 border-rose-400 text-rose-800'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  A. She like noodles.
                </button>
                <button
                  onClick={() => {
                    setBab4Answer('correct');
                    sound.playCorrect();
                  }}
                  className={`btn-bubble py-2.5 px-5 rounded-2xl font-bold text-sm border-2 ${
                    bab4Answer === 'correct'
                      ? 'bg-emerald-100 border-emerald-400 text-emerald-800 ring-2 ring-emerald-300'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  B. She likes noodles.
                </button>
              </div>

              {bab4Answer === 'correct' && (
                <div className="mt-3 text-emerald-600 font-black text-sm flex items-center justify-center gap-1.5 animate-bounce-gentle">
                  <span>🎉 Tepat sekali! He & She selalu menggunakan LIKES!</span>
                </div>
              )}
              {bab4Answer === 'wrong' && (
                <div className="mt-3 text-rose-500 font-bold text-xs">
                  Yuk coba lagi! Ingat: She menggunakan LIKES (ada s-nya).
                </div>
              )}
            </div>
          </div>
        )}

        {/* ---------------- PAGE 6: BAB 5 - DO YOU LIKE? ---------------- */}
        {currentPage === 6 && (
          <div className="animate-fadeIn flex-1">
            <div className="text-center mb-6">
              <span className="bg-teal-100 text-teal-900 text-xs font-black px-3 py-1 rounded-full uppercase">
                BAB 5
              </span>
              <h2 className="text-2xl sm:text-4xl font-black text-slate-900 font-bubble mt-1">
                DO YOU LIKE ...?
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-1">
                Cara bertanya dan menjawab dengan <strong>YES / NO</strong>
              </p>
            </div>

            {/* Explanation box */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-xl mx-auto mb-6 text-center">
              <div className="bg-emerald-50 rounded-2xl p-4 border-2 border-emerald-200">
                <span className="text-xs font-bold text-emerald-600 block uppercase">
                  Jawaban Ya:
                </span>
                <span className="text-xl font-black text-emerald-900 font-bubble">
                  "Yes, I do."
                </span>
              </div>
              <div className="bg-rose-50 rounded-2xl p-4 border-2 border-rose-200">
                <span className="text-xs font-bold text-rose-600 block uppercase">
                  Jawaban Tidak:
                </span>
                <span className="text-xl font-black text-rose-900 font-bubble">
                  "No, I don't."
                </span>
              </div>
            </div>

            {/* Interactive Question with 3D Food */}
            <div className="bg-gradient-to-b from-sky-50 to-teal-50 rounded-3xl p-6 border-4 border-teal-200 text-center flex flex-col items-center">
              <div className="text-sm font-bold text-teal-800 uppercase tracking-wider mb-1">
                Pilih makanan untuk ditanyakan:
              </div>

              <div className="flex flex-wrap justify-center gap-2 mb-4">
                {FOOD_ITEMS.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => {
                      sound.playClick();
                      setBab5Food(f.id);
                      setBab5Choice(null);
                    }}
                    className={`btn-bubble px-3 py-1.5 rounded-xl text-xs font-bold border ${
                      bab5Food === f.id
                        ? 'bg-teal-500 text-white border-teal-600'
                        : 'bg-white text-slate-600 border-slate-200'
                    }`}
                  >
                    {f.name}
                  </button>
                ))}
              </div>

              <Food3DCanvas
                foodId={bab5Food}
                size="md"
                showCardBanner={true}
                onClick={() => sound.playFoodSound(bab5Food)}
              />

              <div className="my-3 text-2xl sm:text-3xl font-black text-teal-950 font-bubble flex items-center justify-center gap-2">
                <span>Do you like {bab5Food}?</span>
                <button
                  onClick={() => sound.speak(`Do you like ${bab5Food}?`)}
                  className="w-8 h-8 rounded-full bg-teal-100 hover:bg-teal-200 text-teal-800 flex items-center justify-center"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>

              {/* Yes / No buttons */}
              <div className="flex flex-wrap items-center justify-center gap-4 mt-2">
                <button
                  onClick={() => {
                    sound.playCorrect();
                    setBab5Choice('yes');
                    sound.speak(`Yes, I do. I like ${bab5Food}.`);
                  }}
                  className={`btn-bubble py-3 px-6 sm:px-8 rounded-2xl font-black text-base sm:text-lg border-2 ${
                    bab5Choice === 'yes'
                      ? 'bg-emerald-500 text-white border-emerald-600 scale-105 shadow-md'
                      : 'bg-white text-emerald-700 border-emerald-300 hover:bg-emerald-50'
                  }`}
                >
                  YES (Yes, I do. I like {bab5Food}.)
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    setBab5Choice('no');
                    sound.speak("No, I don't.");
                  }}
                  className={`btn-bubble py-3 px-6 sm:px-8 rounded-2xl font-black text-base sm:text-lg border-2 ${
                    bab5Choice === 'no'
                      ? 'bg-rose-500 text-white border-rose-600 scale-105 shadow-md'
                      : 'bg-white text-rose-700 border-rose-300 hover:bg-rose-50'
                  }`}
                >
                  NO (No, I don't.)
                </button>
              </div>

              {bab5Choice && (
                <div className="mt-4 bg-white rounded-2xl py-3 px-6 border-2 border-teal-300 animate-pop font-bold text-teal-800 text-base">
                  {bab5Choice === 'yes'
                    ? `🎉 "Yes, I do. I like ${bab5Food}."`
                    : `👍 "No, I don't."`}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ---------------- PAGE 7: BAB 6 - DOES SHE / HE LIKE? ---------------- */}
        {currentPage === 7 && (
          <div className="animate-fadeIn flex-1">
            <div className="text-center mb-6">
              <span className="bg-rose-100 text-rose-900 text-xs font-black px-3 py-1 rounded-full uppercase">
                BAB 6 • ATURAN PENTING
              </span>
              <h2 className="text-2xl sm:text-4xl font-black text-slate-900 font-bubble mt-1">
                DOES SHE / HE LIKE ...?
              </h2>
              <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-1">
                Perhatikan perubahan kata kerja setelah kata <strong>DOES</strong>!
              </p>
            </div>

            {/* Important Rule Spotlight */}
            <div className="bg-amber-100 border-4 border-amber-400 rounded-3xl p-5 mb-6 text-center max-w-xl mx-auto shadow-sm">
              <span className="bg-amber-500 text-white text-xs font-black px-3 py-1 rounded-full uppercase">
                ⚠️ ATURAN EMAS
              </span>
              <div className="text-lg sm:text-xl font-black text-amber-950 font-bubble mt-2">
                Setelah kata <span className="text-rose-600 underline">DOES</span>, gunakan <span className="text-emerald-700 underline">LIKE</span> (bukan likes)!
              </div>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-3 text-xs sm:text-sm">
                <span className="text-emerald-700 font-extrabold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Benar: Does she like noodles?
                </span>
                <span className="text-rose-600 font-extrabold flex items-center gap-1">
                  <XCircle className="w-4 h-4" />
                  Salah: Does she likes noodles?
                </span>
              </div>
            </div>

            {/* Answers Formula */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl mx-auto mb-6">
              <div className="bg-emerald-50 rounded-2xl p-4 border-2 border-emerald-200 text-center">
                <span className="text-xs font-bold text-emerald-700 block">Jika Ya:</span>
                <span className="text-base sm:text-lg font-black text-emerald-950 font-bubble">
                  "Yes, she does." / "Yes, he does."
                </span>
              </div>
              <div className="bg-rose-50 rounded-2xl p-4 border-2 border-rose-200 text-center">
                <span className="text-xs font-bold text-rose-700 block">Jika Tidak:</span>
                <span className="text-base sm:text-lg font-black text-rose-950 font-bubble">
                  "No, she doesn't." / "No, he doesn't."
                </span>
              </div>
            </div>

            {/* Quick check */}
            <div className="bg-white rounded-2xl p-5 border-2 border-slate-200 text-center max-w-xl mx-auto">
              <span className="text-xs font-bold text-slate-500 block mb-2 uppercase">
                Cek Pemahamanmu:
              </span>
              <div className="text-base font-bold text-slate-800 mb-3">
                "Does he ___ rice?"
              </div>

              <div className="flex justify-center gap-4">
                <button
                  onClick={() => {
                    setBab6Answer('correct');
                    sound.playCorrect();
                  }}
                  className={`btn-bubble py-2.5 px-6 rounded-2xl font-black text-sm border-2 ${
                    bab6Answer === 'correct'
                      ? 'bg-emerald-500 text-white border-emerald-600'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  LIKE
                </button>
                <button
                  onClick={() => {
                    setBab6Answer('wrong');
                    sound.playWrong();
                  }}
                  className={`btn-bubble py-2.5 px-6 rounded-2xl font-black text-sm border-2 ${
                    bab6Answer === 'wrong'
                      ? 'bg-rose-500 text-white border-rose-600'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  LIKES
                </button>
              </div>

              {bab6Answer === 'correct' && (
                <div className="mt-3 text-emerald-600 font-black text-sm flex items-center justify-center gap-1.5 animate-bounce-gentle">
                  <span>⭐ Hebat! Karena sudah ada 'Does', kata kerjanya kembali ke 'LIKE'!</span>
                </div>
              )}
              {bab6Answer === 'wrong' && (
                <div className="mt-3 text-rose-500 font-bold text-xs">
                  Ingat: jika sudah ada 'Does', jangan tambah -s lagi! Pilih 'LIKE'.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Bottom Navigation Buttons: Previous / Next & Final CTA */}
        <div className="flex items-center justify-between border-t-2 border-slate-100 pt-6 mt-6">
          <button
            onClick={() => goToPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
            className={`btn-bubble flex items-center gap-2 py-3 px-5 rounded-2xl font-black text-sm border-2 ${
              currentPage === 1
                ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400 border-slate-200'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-sky-50'
            }`}
          >
            <ChevronLeft className="w-5 h-5" />
            <span>← Previous</span>
          </button>

          {currentPage < totalPages ? (
            <button
              onClick={() => goToPage(currentPage + 1)}
              className="btn-bubble flex items-center gap-2 py-3 px-6 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-sm sm:text-base border-2 border-amber-500 shadow-md"
            >
              <span>Next (Halaman {currentPage + 1}) →</span>
              <ChevronRight className="w-5 h-5" />
            </button>
          ) : (
            <button
              onClick={() => {
                sound.playVictory();
                onCompleteBook();
              }}
              className="btn-bubble flex items-center gap-2 py-3 px-7 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-black text-base border-2 border-emerald-600 shadow-lg shadow-emerald-200 animate-bounce-gentle"
            >
              <span>Lanjut ke Latihan (Practice Zone)</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
