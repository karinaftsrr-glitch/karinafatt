import React, { useState, useEffect, useRef } from 'react';
import { Player, LearningProgress, Achievement, FoodId } from '../types';
import { Food3DCanvas } from './Food3DCanvas';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import {
  Trophy,
  Users,
  Star,
  Target,
  Zap,
  RotateCcw,
  CheckCircle2,
  XCircle,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Crown,
  Timer,
  Play
} from 'lucide-react';

interface KompetisiSkorProps {
  progress: LearningProgress;
  achievements: Achievement[];
  totalScore: number;
  onBackToLearning: () => void;
  onPlayAgain: () => void;
  onProgressUpdate: (key: keyof LearningProgress, val: number) => void;
  onUnlockBadge: (id: string) => void;
}

interface RoundPlayerRecord {
  playerId: number;
  playerName: string;
  isCorrect: boolean;
  timeTaken: number; // in seconds
  chosenOption: string;
  pointsEarned: number;
}

export const KompetisiSkor: React.FC<KompetisiSkorProps> = ({
  progress,
  achievements,
  onBackToLearning,
  onProgressUpdate,
  onUnlockBadge,
}) => {
  // Steps: setup -> rules -> turn_ready -> turn_answering -> round_winner -> final
  const [compState, setCompState] = useState<
    'setup' | 'rules' | 'turn_ready' | 'turn_answering' | 'round_winner' | 'final'
  >('setup');

  // Player Names & State
  const [players, setPlayers] = useState<Player[]>([
    { id: 1, name: 'Adit', score: 0, correctAnswers: 0, fastAnswers: 0, avatarColor: 'bg-sky-500' },
    { id: 2, name: 'Sinta', score: 0, correctAnswers: 0, fastAnswers: 0, avatarColor: 'bg-amber-500' },
    { id: 3, name: 'Bima', score: 0, correctAnswers: 0, fastAnswers: 0, avatarColor: 'bg-emerald-500' },
  ]);

  // Questions for the Turn-Based Battle (5 engaging rounds)
  const competitionQuestions = [
    {
      roundNum: 1,
      q: 'What food is this?',
      foodId: 'noodles' as FoodId,
      options: ['Noodles', 'Rice', 'Tofu'],
      correct: 'Noodles',
    },
    {
      roundNum: 2,
      q: 'She ___ rice.',
      foodId: 'rice' as FoodId,
      options: ['likes', 'like', 'liking'],
      correct: 'likes',
    },
    {
      roundNum: 3,
      q: 'Do you like meatball?',
      foodId: 'meatball' as FoodId,
      options: ['Yes, I do.', 'Yes, I does.', 'No, I don’t.'],
      correct: 'Yes, I do.',
    },
    {
      roundNum: 4,
      q: 'What food is this?',
      foodId: 'tofu' as FoodId,
      options: ['Tofu', 'Omelet', 'Meatball'],
      correct: 'Tofu',
    },
    {
      roundNum: 5,
      q: 'Does he like omelet?',
      foodId: 'omelet' as FoodId,
      options: ['Yes, he does.', 'Yes, he do.', 'Yes, he likes.'],
      correct: 'Yes, he does.',
    },
  ];

  const [currentRoundIdx, setCurrentRoundIdx] = useState<number>(0);
  const [currentPlayerIdx, setCurrentPlayerIdx] = useState<number>(0);

  // Timer states during answering
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const startTimeRef = useRef<number>(0);
  const timerIntervalRef = useRef<any>(null);

  // Store records of the 3 players for the current round
  const [currentRoundRecords, setCurrentRoundRecords] = useState<RoundPlayerRecord[]>([]);

  // Start Competition Flow
  const handleStartRules = () => {
    sound.playClick();
    setCompState('rules');
  };

  const handleStartMatch = () => {
    sound.playVictory();
    setCurrentRoundIdx(0);
    setCurrentPlayerIdx(0);
    setCurrentRoundRecords([]);
    setCompState('turn_ready');
  };

  // Player clicks "I'm Ready! Start!"
  const handleStartPlayerTurn = () => {
    sound.playCountdown(true);
    setElapsedSeconds(0);
    startTimeRef.current = Date.now();
    setCompState('turn_answering');

    // Run high precision timer every 100ms
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    timerIntervalRef.current = setInterval(() => {
      const now = Date.now();
      const seconds = (now - startTimeRef.current) / 1000;
      if (seconds >= 10.0) {
        // Time out
        clearInterval(timerIntervalRef.current);
        handlePlayerSubmitAnswer('__TIMEOUT__', 10.0);
      } else {
        setElapsedSeconds(seconds);
      }
    }, 100);
  };

  // Player submits answer
  const handlePlayerSubmitAnswer = (chosenOpt: string, forcedTime?: number) => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    const timeTaken = forcedTime !== undefined ? forcedTime : (Date.now() - startTimeRef.current) / 1000;
    const finalSeconds = parseFloat(timeTaken.toFixed(2));
    const currQuestion = competitionQuestions[currentRoundIdx];
    const currPlayer = players[currentPlayerIdx];
    const isCorrect = chosenOpt === currQuestion.correct;

    if (isCorrect) {
      sound.playCorrect();
    } else {
      sound.playWrong();
    }

    const newRecord: RoundPlayerRecord = {
      playerId: currPlayer.id,
      playerName: currPlayer.name,
      isCorrect,
      timeTaken: finalSeconds,
      chosenOption: chosenOpt,
      pointsEarned: 0, // calculated in round reveal
    };

    const updatedRecords = [...currentRoundRecords, newRecord];
    setCurrentRoundRecords(updatedRecords);

    // Check if ALL 3 players have taken their turn for this question
    if (updatedRecords.length === players.length) {
      // All 3 players finished! Calculate points and announce round winner
      calculateRoundWinners(updatedRecords);
    } else {
      // Next player's turn for the SAME question!
      setCurrentPlayerIdx((prev) => prev + 1);
      setCompState('turn_ready');
    }
  };

  // Calculate Round Winner: Fastest & Correct wins!
  const calculateRoundWinners = (records: RoundPlayerRecord[]) => {
    // Sort records: Correct answers first, then sorted by fastest time (ascending)
    const sorted = [...records].sort((a, b) => {
      if (a.isCorrect && !b.isCorrect) return -1;
      if (!a.isCorrect && b.isCorrect) return 1;
      if (a.isCorrect && b.isCorrect) return a.timeTaken - b.timeTaken;
      return a.timeTaken - b.timeTaken;
    });

    // Award Points:
    // 1st (fastest correct): 100 pts
    // 2nd (correct): 70 pts
    // 3rd (correct): 50 pts
    // incorrect: 0 pts
    const pointsMap = [100, 70, 50];

    const finalRecordsWithPoints = sorted.map((rec, index) => {
      let pts = 0;
      if (rec.isCorrect) {
        pts = pointsMap[index] || 40;
      }
      return { ...rec, pointsEarned: pts };
    });

    // Update global players score
    setPlayers((prevPlayers) =>
      prevPlayers.map((p) => {
        const found = finalRecordsWithPoints.find((r) => r.playerId === p.id);
        if (found) {
          return {
            ...p,
            score: p.score + found.pointsEarned,
            correctAnswers: p.correctAnswers + (found.isCorrect ? 1 : 0),
            fastAnswers: p.fastAnswers + (found.pointsEarned === 100 ? 1 : 0),
          };
        }
        return p;
      })
    );

    setCurrentRoundRecords(finalRecordsWithPoints);
    setCompState('round_winner');
    sound.playVictory();
    confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
  };

  // Next Round or Grand Final
  const handleProceedNextRound = () => {
    sound.playClick();
    if (currentRoundIdx + 1 >= competitionQuestions.length) {
      // Grand Final Podium!
      setCompState('final');
      onProgressUpdate('competition', 100);
      onUnlockBadge('game_champion');
      sound.playVictory();
      confetti({ particleCount: 120, spread: 90, origin: { y: 0.5 } });
    } else {
      setCurrentRoundIdx((prev) => prev + 1);
      setCurrentPlayerIdx(0);
      setCurrentRoundRecords([]);
      setCompState('turn_ready');
    }
  };

  // Grand Final Ranking
  const grandFinalRanked = [...players].sort((a, b) => b.score - a.score);

  return (
    <div className="py-6 sm:py-8 px-4 max-w-6xl mx-auto animate-fadeIn">
      {/* ---------------- TOP BANNER ---------------- */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-1.5 bg-rose-100 text-rose-900 px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase mb-1">
            <Trophy className="w-4 h-4 text-rose-600" />
            <span>3 PLAYER TURN-BASED BATTLE</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-slate-900 font-bubble">
            ARENA BATTLE GILIRAN
          </h1>
          <p className="text-xs sm:text-sm font-semibold text-slate-500">
            Semua pemain menjawab bergantian ➔ Yang paling cepat & benar jadi pemenangnya!
          </p>
        </div>

        <button
          onClick={() => {
            sound.playClick();
            onBackToLearning();
          }}
          className="btn-bubble flex items-center gap-2 py-2.5 px-5 rounded-2xl bg-white hover:bg-sky-50 text-sky-800 font-black text-sm border-2 border-sky-300"
        >
          <BookOpen className="w-4 h-4" />
          <span>Kembali ke Bahan Ajar</span>
        </button>
      </div>

      {/* ---------------- MAIN ARENA BOX ---------------- */}
      <div className="bg-white rounded-3xl border-8 border-rose-200 shadow-xl p-6 sm:p-10 mb-12">
        {/* ================= STEP 1: SETUP PLAYERS ================= */}
        {compState === 'setup' && (
          <div className="animate-fadeIn max-w-xl mx-auto text-center">
            <div className="w-20 h-20 rounded-full bg-rose-100 border-4 border-rose-300 flex items-center justify-center text-4xl mx-auto mb-4">
              👥
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 font-bubble mb-2">
              Masukkan Nama 3 Pemain
            </h2>
            <p className="text-xs sm:text-sm font-medium text-slate-500 mb-6">
              Ketiga pemain akan menjawab setiap soal secara bergiliran. Siapa yang paling cepat & benar akan memenangkan ronde!
            </p>

            <div className="space-y-4 mb-8 text-left">
              {players.map((p) => (
                <div key={p.id} className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-2xl ${p.avatarColor} text-white font-black flex items-center justify-center text-sm shadow-md shrink-0`}
                  >
                    P{p.id}
                  </div>
                  <div className="flex-1">
                    <label className="text-xs font-black text-slate-400 block mb-1 uppercase">
                      Player {p.id} Name:
                    </label>
                    <input
                      type="text"
                      value={p.name}
                      onChange={(e) => {
                        const val = e.target.value;
                        setPlayers((prev) =>
                          prev.map((item) => (item.id === p.id ? { ...item, name: val } : item))
                        );
                      }}
                      className="w-full py-3 px-4 rounded-2xl bg-slate-50 border-2 border-slate-200 focus:border-rose-400 focus:bg-white text-slate-800 font-bold outline-hidden transition-all text-base"
                      placeholder={`Nama Pemain ${p.id}`}
                    />
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={handleStartRules}
              className="w-full btn-bubble py-4 rounded-3xl bg-rose-500 hover:bg-rose-400 text-white font-black text-lg border-2 border-rose-600 shadow-xl"
            >
              Lanjut ke Aturan Battle →
            </button>
          </div>
        )}

        {/* ================= STEP 2: RULES ================= */}
        {compState === 'rules' && (
          <div className="animate-fadeIn max-w-xl mx-auto text-center">
            <span className="text-xs font-black bg-rose-100 text-rose-800 px-3 py-1 rounded-full uppercase">
              SISTEM GILIRAN BATTLE
            </span>
            <h2 className="text-3xl font-black text-slate-900 font-bubble mt-2 mb-4">
              ATURAN PERMAINAN
            </h2>

            <div className="bg-rose-50/60 rounded-3xl p-6 border-3 border-rose-200 text-left space-y-3.5 mb-8">
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-rose-500 text-white flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  1
                </span>
                <span className="text-sm font-bold text-slate-800">
                  <strong>Semua pemain giliran menjawab:</strong> Pemain 1 ➔ Pemain 2 ➔ Pemain 3 menjawab soal yang sama satu per satu.
                </span>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-rose-500 text-white flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  2
                </span>
                <span className="text-sm font-bold text-slate-800">
                  <strong>Waktu tercatat otomatis:</strong> Stopwatch akan mengukur seberapa cepat kamu memilih jawaban.
                </span>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-rose-500 text-white flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  3
                </span>
                <span className="text-sm font-bold text-slate-800">
                  <strong>Paling cepat & benar jadi pemenang:</strong> Pemain yang menjawab benar dengan waktu tercepat meraih poin juara ronde (+100 poin)!
                </span>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-rose-500 text-white flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  4
                </span>
                <span className="text-sm font-bold text-slate-800">
                  <strong>Oper perangkat dengan adil:</strong> Setelah giliranmu selesai, oper perangkat ke teman berikutnya tanpa memberitahu jawaban.
                </span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={() => setCompState('setup')}
                className="btn-bubble py-3 px-6 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold border-2 border-slate-300"
              >
                Ganti Nama
              </button>
              <button
                onClick={handleStartMatch}
                className="flex-1 btn-bubble py-3.5 px-8 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 text-white font-black text-lg border-2 border-rose-600 shadow-xl"
              >
                🚀 MULAI BATTLE GILIRAN!
              </button>
            </div>
          </div>
        )}

        {/* ================= STEP 3: TURN READY (OPER PERANGKAT KE PEMAIN) ================= */}
        {compState === 'turn_ready' && (
          <div className="animate-fadeIn max-w-lg mx-auto text-center py-6">
            <span className="text-xs font-black bg-slate-100 text-slate-600 px-3 py-1 rounded-full uppercase">
              RONDE {currentRoundIdx + 1} DARI {competitionQuestions.length}
            </span>

            {/* Turn Prompt Banner */}
            <div className="my-6">
              <div
                className={`w-24 h-24 rounded-3xl ${players[currentPlayerIdx].avatarColor} text-white font-black text-3xl flex items-center justify-center mx-auto mb-4 shadow-xl border-4 border-white animate-pop`}
              >
                P{players[currentPlayerIdx].id}
              </div>
              <div className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">
                OPER PERANGKAT KE:
              </div>
              <h2 className="text-3xl sm:text-5xl font-black text-slate-900 font-bubble">
                GILIRAN {players[currentPlayerIdx].name.toUpperCase()}!
              </h2>
              <p className="text-sm font-bold text-slate-500 mt-2">
                Pemain lain jangan melihat layar ya! Tekan tombol saat kamu sudah siap.
              </p>
            </div>

            <div className="bg-amber-50 rounded-2xl p-4 border-2 border-amber-200 mb-8 text-xs font-bold text-amber-900">
              ⚡ Stopwatch akan otomatis berjalan begitu kamu menekan tombol di bawah!
            </div>

            <button
              onClick={handleStartPlayerTurn}
              className="w-full btn-bubble py-4 sm:py-5 rounded-3xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-black text-xl border-2 border-emerald-600 shadow-xl flex items-center justify-center gap-3"
            >
              <Play className="w-6 h-6 fill-white" />
              <span>SAYA SIAP! MULAI SOAL</span>
            </button>
          </div>
        )}

        {/* ================= STEP 4: TURN ANSWERING (STOPWATCH BERJALAN) ================= */}
        {compState === 'turn_answering' && (
          <div className="animate-fadeIn">
            {/* Header: Turn Indicator & Stopwatch */}
            <div className="flex items-center justify-between bg-slate-50 rounded-2xl p-4 border-2 border-slate-200 mb-6">
              <div className="flex items-center gap-2">
                <span
                  className={`w-8 h-8 rounded-full ${players[currentPlayerIdx].avatarColor} text-white font-black text-xs flex items-center justify-center`}
                >
                  P{players[currentPlayerIdx].id}
                </span>
                <span className="font-black text-slate-800 text-base font-bubble">
                  {players[currentPlayerIdx].name}'s Turn
                </span>
              </div>

              {/* Live Stopwatch Display */}
              <div className="flex items-center gap-2 bg-rose-500 text-white px-4 py-1.5 rounded-full font-black text-sm shadow-md animate-pulse">
                <Timer className="w-4 h-4" />
                <span>{elapsedSeconds.toFixed(1)}s</span>
              </div>
            </div>

            {/* Question Stage */}
            <div className="flex flex-col md:flex-row items-center justify-around gap-6 mb-8">
              <Food3DCanvas
                foodId={competitionQuestions[currentRoundIdx].foodId}
                size="md"
                showCardBanner={false}
              />

              <div className="flex flex-col items-center md:items-start w-full max-w-md">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Pilih jawaban secepat mungkin:
                </span>
                <h3 className="text-2xl sm:text-3xl font-black text-slate-800 font-bubble mb-6 text-center md:text-left">
                  {competitionQuestions[currentRoundIdx].q}
                </h3>

                {/* Answer Options */}
                <div className="grid grid-cols-1 gap-3 w-full">
                  {competitionQuestions[currentRoundIdx].options.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => handlePlayerSubmitAnswer(opt)}
                      className="btn-bubble py-4 px-6 rounded-2xl bg-white hover:bg-rose-50 text-slate-800 font-black text-lg border-3 border-slate-200 hover:border-rose-400 transition-all text-left flex items-center justify-between"
                    >
                      <span>{opt}</span>
                      <ArrowRight className="w-5 h-5 text-slate-300" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= STEP 5: ROUND REVEAL & WINNER COMPARISON ================= */}
        {compState === 'round_winner' && (
          <div className="animate-fadeIn text-center max-w-2xl mx-auto">
            <span className="text-xs font-black bg-amber-100 text-amber-900 px-4 py-1 rounded-full uppercase tracking-wider">
              HASIL RONDE {currentRoundIdx + 1}
            </span>

            {/* Round Champion Highlight */}
            {currentRoundRecords[0]?.isCorrect ? (
              <div className="my-6 bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-400 rounded-3xl p-6 border-4 border-amber-500 shadow-xl text-amber-950 animate-pop">
                <Crown className="w-10 h-10 text-amber-700 mx-auto animate-bounce mb-1" />
                <div className="text-xs font-black uppercase tracking-widest text-amber-900">
                  👑 PEMENANG RONDE INI (TERCEPAT & BENAR!):
                </div>
                <h2 className="text-3xl sm:text-4xl font-black font-bubble mt-1">
                  {currentRoundRecords[0].playerName}
                </h2>
                <div className="inline-flex items-center gap-2 mt-2 bg-white/70 px-4 py-1.5 rounded-full text-sm font-black">
                  <span>⚡ Waktu: {currentRoundRecords[0].timeTaken} detik</span>
                  <span>•</span>
                  <span>+{currentRoundRecords[0].pointsEarned} Poin</span>
                </div>
              </div>
            ) : (
              <div className="my-6 bg-slate-100 rounded-3xl p-6 border-2 border-slate-300 text-slate-700">
                <h3 className="text-xl font-black font-bubble">
                  Semua pemain belum menjawab dengan benar pada ronde ini!
                </h3>
              </div>
            )}

            {/* Full Round Leaderboard for all 3 players */}
            <div className="bg-slate-50 rounded-3xl p-6 border-3 border-slate-200 mb-8 text-left">
              <div className="text-xs font-black text-slate-500 uppercase mb-3">
                Urutan Kecepatan & Ketepatan Ronde Ini:
              </div>

              <div className="space-y-3">
                {currentRoundRecords.map((rec, idx) => (
                  <div
                    key={rec.playerId}
                    className={`p-4 rounded-2xl border-2 flex items-center justify-between ${
                      idx === 0 && rec.isCorrect
                        ? 'bg-amber-100/70 border-amber-400 ring-2 ring-amber-200'
                        : rec.isCorrect
                        ? 'bg-white border-slate-200'
                        : 'bg-rose-50 border-rose-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl font-black">
                        {idx === 0 && rec.isCorrect ? '🥇' : idx === 1 && rec.isCorrect ? '🥈' : idx === 2 && rec.isCorrect ? '🥉' : '❌'}
                      </span>
                      <div>
                        <div className="font-black text-slate-900 text-base">
                          {rec.playerName}
                        </div>
                        <div className="text-xs font-semibold text-slate-500">
                          Jawaban: "{rec.chosenOption}" • Waktu: {rec.timeTaken}s
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="font-black text-slate-800 text-lg font-bubble block">
                        +{rec.pointsEarned} pts
                      </span>
                      <span
                        className={`text-[10px] font-black uppercase ${
                          rec.isCorrect ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        {rec.isCorrect ? 'BENAR' : 'SALAH / WAKTU HABIS'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Next Round Button */}
            <button
              onClick={handleProceedNextRound}
              className="btn-bubble py-4 px-10 rounded-3xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-lg border-2 border-amber-500 shadow-xl flex items-center justify-center gap-2 mx-auto"
            >
              <span>
                {currentRoundIdx + 1 >= competitionQuestions.length
                  ? 'Lihat Papan Skor Akhir 🏆'
                  : 'Lanjut ke Ronde Berikutnya →'}
              </span>
            </button>
          </div>
        )}

        {/* ================= STEP 6: GRAND FINAL PODIUM ================= */}
        {compState === 'final' && (
          <div className="animate-fadeIn text-center">
            <span className="text-xs font-black bg-amber-100 text-amber-900 px-4 py-1.5 rounded-full uppercase tracking-wider">
              BATTLE SELESAI
            </span>
            <h2 className="text-3xl sm:text-5xl font-black text-slate-900 font-bubble mt-2 mb-2">
              JUARA UMUM BATTLE 🏆
            </h2>
            <p className="text-xs sm:text-sm font-semibold text-slate-500 mb-8">
              Pemenang ditentukan berdasarkan kombinasi jawaban benar dan waktu tercepat!
            </p>

            {/* 3-Place Podium */}
            <div className="flex justify-center items-end gap-3 sm:gap-6 mb-10 max-w-xl mx-auto">
              {/* 2nd Place */}
              <div className="flex-1 flex flex-col items-center">
                <span className="text-4xl mb-1">🥈</span>
                <span className="font-black text-slate-800 text-sm truncate max-w-[90px]">
                  {grandFinalRanked[1]?.name}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  {grandFinalRanked[1]?.score} pts
                </span>
                <div className="w-full bg-slate-200 h-28 rounded-t-2xl border-4 border-slate-300 mt-2 flex items-center justify-center font-black text-slate-600 text-xl font-bubble shadow-inner">
                  2nd
                </div>
              </div>

              {/* 1st Place (Champion) */}
              <div className="flex-1 flex flex-col items-center">
                <Crown className="w-8 h-8 text-amber-500 animate-bounce" />
                <span className="text-5xl mb-1">🥇</span>
                <span className="font-black text-amber-950 text-base truncate max-w-[100px]">
                  {grandFinalRanked[0]?.name}
                </span>
                <span className="text-sm font-black text-amber-600">
                  {grandFinalRanked[0]?.score} pts
                </span>
                <div className="w-full bg-gradient-to-b from-amber-300 to-amber-400 h-40 rounded-t-3xl border-4 border-amber-500 mt-2 flex items-center justify-center font-black text-amber-950 text-3xl font-bubble shadow-lg">
                  1st
                </div>
              </div>

              {/* 3rd Place */}
              <div className="flex-1 flex flex-col items-center">
                <span className="text-4xl mb-1">🥉</span>
                <span className="font-black text-slate-800 text-sm truncate max-w-[90px]">
                  {grandFinalRanked[2]?.name}
                </span>
                <span className="text-xs font-bold text-slate-500">
                  {grandFinalRanked[2]?.score} pts
                </span>
                <div className="w-full bg-amber-100 h-20 rounded-t-2xl border-4 border-amber-200 mt-2 flex items-center justify-center font-black text-amber-800 text-lg font-bubble shadow-inner">
                  3rd
                </div>
              </div>
            </div>

            {/* Summary Statistics Table */}
            <div className="bg-slate-50 rounded-3xl p-6 border-3 border-slate-200 max-w-2xl mx-auto mb-8 text-left">
              <h3 className="text-base font-black text-slate-800 font-bubble mb-3 uppercase">
                Rincian Skor & Kemenangan Ronde
              </h3>
              <div className="divide-y divide-slate-200">
                {grandFinalRanked.map((p, idx) => (
                  <div key={p.id} className="py-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-xl">
                        {idx === 0 ? '🥇' : idx === 1 ? '🥈' : '🥉'}
                      </span>
                      <div>
                        <span className="font-black text-slate-900 block">{p.name}</span>
                        <span className="text-xs font-semibold text-slate-500">
                          {p.correctAnswers} Jawaban Benar • {p.fastAnswers} Kali Tercepat
                        </span>
                      </div>
                    </div>
                    <span className="text-2xl font-black text-slate-800 font-bubble">
                      {p.score} pts
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Buttons: PLAY AGAIN & BACK TO LEARNING */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => {
                  sound.playClick();
                  setPlayers((prev) =>
                    prev.map((p) => ({ ...p, score: 0, correctAnswers: 0, fastAnswers: 0 }))
                  );
                  setCompState('setup');
                }}
                className="btn-bubble py-3.5 px-8 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-base border-2 border-amber-500 shadow-md flex items-center gap-2"
              >
                <RotateCcw className="w-5 h-5" />
                <span>MAIN BATTLE LAGI</span>
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onBackToLearning();
                }}
                className="btn-bubble py-3.5 px-8 rounded-2xl bg-sky-500 hover:bg-sky-400 text-white font-black text-base border-2 border-sky-600 shadow-md flex items-center gap-2"
              >
                <BookOpen className="w-5 h-5" />
                <span>KEMBALI KE MATERI</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ---------------- 3. PROGRESS SYSTEM ---------------- */}
      <div className="bg-white rounded-3xl border-8 border-sky-200 shadow-xl p-6 sm:p-8 mb-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-sky-100 flex items-center justify-center text-2xl">
            📊
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 font-bubble">
              YOUR LEARNING PROGRESS
            </h2>
            <p className="text-xs sm:text-sm font-semibold text-slate-500">
              Pantau perkembangan belajarmu dari awal hingga akhir!
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {[
            { label: 'Vocabulary', val: progress.vocabulary, color: 'bg-sky-500' },
            { label: 'Grammar', val: progress.grammar, color: 'bg-violet-500' },
            { label: 'Practice', val: progress.practice, color: 'bg-emerald-500' },
            { label: 'Games', val: progress.games, color: 'bg-orange-500' },
            { label: 'Competition', val: progress.competition, color: 'bg-rose-500' },
          ].map((item) => (
            <div key={item.label} className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
              <div className="flex items-center justify-between text-xs font-black text-slate-700 mb-2">
                <span>{item.label}</span>
                <span className="font-bubble text-slate-900">{item.val}%</span>
              </div>
              <div className="w-full bg-slate-200 h-3 rounded-full overflow-hidden">
                <div
                  style={{ width: `${item.val}%` }}
                  className={`h-full ${item.color} transition-all duration-700`}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ---------------- 4. ACHIEVEMENTS & BADGES ---------------- */}
      <div className="bg-white rounded-3xl border-8 border-amber-200 shadow-xl p-6 sm:p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-2xl">
            🏅
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 font-bubble">
              EDUCATIONAL BADGES & ACHIEVEMENTS
            </h2>
            <p className="text-xs sm:text-sm font-semibold text-slate-500">
              Kumpulkan semua lencana prestasi dengan menyelesaikan latihan dan game!
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {achievements.map((ach) => (
            <div
              key={ach.id}
              className={`rounded-2xl p-4 border-3 text-center flex flex-col items-center justify-between transition-all ${
                ach.unlocked
                  ? 'bg-amber-50/80 border-amber-400 shadow-md ring-2 ring-amber-200'
                  : 'bg-slate-50 border-slate-200 opacity-60'
              }`}
            >
              <div className="w-14 h-14 rounded-full bg-white border-2 border-slate-200 flex items-center justify-center text-2xl mb-2 shadow-xs">
                {ach.iconType === 'star' && '⭐'}
                {ach.iconType === 'target' && '🎯'}
                {ach.iconType === 'puzzle' && '🧩'}
                {ach.iconType === 'zap' && '⚡'}
                {ach.iconType === 'trophy' && '🏆'}
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-sm font-bubble">
                  {ach.title}
                </h4>
                <p className="text-[11px] font-semibold text-slate-500 mt-1 leading-snug">
                  {ach.description}
                </p>
              </div>

              <div className="mt-3">
                {ach.unlocked ? (
                  <span className="inline-flex items-center gap-1 text-[10px] font-black text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300">
                    <ShieldCheck className="w-3 h-3" /> Unlocked
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-200 px-2 py-0.5 rounded-full">
                    Locked
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
